# Linux Adaptive Optimization Engine (LAO)

**Versão:** 1.4.0-alpha1  
**Linguagem:** GNU Bash 4.4+  
**Plataformas-alvo:** Linux x86_64, x86, AArch64, ARM, PowerPC, RISC-V e s390x, conforme interfaces expostas pelo kernel  
**Famílias de distribuição reconhecidas:** Arch, Debian/Ubuntu e Fedora, usando `ID` e tokens de `ID_LIKE`  
**Comportamento padrão:** somente leitura

O LAO é um mecanismo modular de inventário, diagnóstico e ajuste runtime conservador. Ele verifica interfaces reais em `/sys`, `/proc` e ferramentas já instaladas. A presença de uma CPU Intel/AMD, GPU ou distribuição com determinado nome **não** é tratada como prova de que um recurso específico existe.

> **Escopo honesto da versão 1.4.0-alpha1:** perfis aplicam governor CPUFreq e EPP de forma condicional, quando o driver anuncia os valores e nenhum gerenciador de energia concorrente é detectado. Há controles runtime adicionais, todos manuais e sem valores automáticos: `vm.swappiness` (0–200), `vm.vfs_cache_pressure` (0–1000), `vm.dirty_ratio` e `vm.dirty_background_ratio` (0–100, respeitando a relação entre ambos), scheduler de I/O para dispositivo explicitamente escolhido e algoritmo TCP anunciado pelo kernel. Os motores de ZRAM/ZSWAP/THP/NUMA, NVMe power, GPU tuning, network tuning, serviços, desktop, boot, Kconfig e kernel deployment continuam total ou parcialmente em diagnóstico. O Kernel Builder prepara e pode compilar em diretório `O=` separado, mas não instala o kernel nem altera initramfs/bootloader.

## 1. Arquitetura

```text
linux-adaptive-optimization/
├── lao
├── lib/
│   ├── common.sh            # logging, state, lock, writes com diário prévio
│   ├── detect.sh            # OS, CPU, RAM, GPU, virtualização, inventário
│   ├── modules.sh           # CPUFreq/EPP e controles manuais de memória/storage/rede
│   ├── state.sh             # rollback validado e sem sobrescrever conflitos
│   └── kernel_builder.sh    # configuração/compilação local e out-of-tree
├── config/
│   └── default.conf
├── docs/
│   ├── ARCHITECTURE.md
│   ├── AUDIT-1.3.0.md
│   ├── COMPATIBILITY.md
│   ├── IMPLEMENTATION-STATUS-1.4.0-alpha1.md
│   ├── RESEARCH.md
│   ├── KNOWN-LIMITATIONS.md
│   └── TEST-REPORT.md
├── tests/
│   └── run.sh
├── CHANGELOG.md
├── LICENSE
└── README.md
```

O pipeline operacional é:

1. Descoberta de distribuição, kernel, virtualização, CPU, memória, GPU e dispositivos.
2. Inventário de interfaces e capacidades expostas.
3. Diagnóstico por módulo.
4. Seleção de alvos do perfil.
5. Verificação de compatibilidade e de controladores concorrentes.
6. Dry-run ou gravação prévia da intenção.
7. Escrita runtime, leitura de verificação e log.
8. Rollback condicional, preservando alterações externas.

## 2. Requisitos

Obrigatórios:

- Linux com Bash 4.4 ou superior.
- `awk`, `sed`, `grep`, `base64`, `date`, `uname`, `getconf`, `stat`, `sync`, `mktemp`, `df`, `find` e utilitários GNU comuns.
- `/proc` e `/sys` montados para inventário completo.

Opcionais, detectados somente quando instalados:

- CPU/hardware: `lscpu`, `lspci`, `lsusb`, `dmidecode`, `sensors`, `smartctl`, `nvme`.
- Memória/armazenamento: `free`, `swapon`, `zramctl`, `lsblk`, `findmnt`, `fstrim`.
- Gráficos: `glxinfo`, `vulkaninfo`, `vainfo`, `nvidia-smi`.
- Rede: `ip`, `iw`, `tc`, `ethtool`.
- Sistema: `systemctl`, `systemd-analyze`, `systemd-detect-virt`, `mokutil`, `firewall-cmd`, `ufw`.
- Benchmark: `sysbench`.
- Kernel build: `make`, GCC ou Clang, `bc`, `flex`, `bison`, `perl`, `python3`; `pahole` quando a configuração exigir BTF. A impressão digital de fonte também usa `find`, `sort`, `xargs` e `sha256sum`.

O Kernel Builder também exige `sha256sum` para fixar a identidade da árvore.

O LAO **não instala dependências**, não atualiza o sistema, não adiciona repositórios e não substitui pacotes.

## 3. Instalação e primeiro diagnóstico

Extraia o arquivo e entre no diretório:

```bash
unzip linux-adaptive-optimization-1.4.0-alpha1.zip
cd linux-adaptive-optimization-1.4.0-alpha1
chmod +x lao tests/run.sh
./lao --help
./lao --analyze
```

O diagnóstico pode ser executado como usuário comum. Sem ferramentas opcionais ou acesso ao hardware, os respectivos campos aparecem como indisponíveis ou não verificados; o LAO não tenta instalar o que falta.

### Comandos principais

```bash
# Diagnóstico completo, somente leitura
./lao --analyze

# Diagnóstico de um subsistema
./lao --module cpu
./lao --module memory
./lao --module storage
./lao --module gpu
./lao --module network

# Relatório técnico em texto
./lao --report

# Lista de módulos e estados
./lao --list-modules

# Plano sem alterar nem gravar estado
./lao --dry-run --optimize --profile gaming

# Aplicar perfil conservador de CPU (requer root)
sudo ./lao --optimize --profile balanced

# Aplicar somente CPUFreq/EPP
sudo ./lao --optimize --module cpu --profile performance

# Alterações manuais opcionais: sempre escolha o valor conscientemente
sudo ./lao --dry-run --optimize --vm-swappiness 80
sudo ./lao --dry-run --optimize --vm-vfs-cache-pressure 150
sudo ./lao --dry-run --optimize --vm-dirty-ratio 30 --vm-dirty-background-ratio 10
sudo ./lao --dry-run --optimize --device nvme0n1 --io-scheduler none
sudo ./lao --dry-run --optimize --tcp-congestion-control bbr

# Depois de revisar o plano, remova --dry-run para aplicar
sudo ./lao --optimize --vm-swappiness 80
sudo ./lao --optimize --vm-vfs-cache-pressure 150
sudo ./lao --optimize --vm-dirty-ratio 30 --vm-dirty-background-ratio 10
sudo ./lao --optimize --device nvme0n1 --io-scheduler none
sudo ./lao --optimize --tcp-congestion-control bbr

# É possível combinar controles manuais numa execução
sudo ./lao --dry-run --optimize --vm-swappiness 80 \
  --device nvme0n1 --io-scheduler none --tcp-congestion-control bbr

# Perfil custom: cada valor ainda precisa ser anunciado pelo kernel
sudo ./lao --dry-run --optimize --profile custom --governor schedutil --epp balance_performance

# Reverter mudanças gerenciadas pelo LAO
sudo ./lao --rollback
sudo ./lao --rollback-module cpu
sudo ./lao --rollback-module memory
sudo ./lao --rollback-module storage
sudo ./lao --rollback-module network

# Benchmark CPU repetido; sysbench deve existir previamente
./lao --benchmark --benchmark-runs 3 --benchmark-seconds 5
```

`--report` grava um arquivo em `${XDG_STATE_HOME:-$HOME/.local/state}/lao/reports/`.

## 4. Perfis de CPU e controles manuais

Os perfis automáticos atuam somente no subsistema CPUFreq/EPP. Os controles de memória, armazenamento e rede não recebem valores padrão de nenhum perfil: exigem opções explícitas na linha de comando.

### Perfis CPUFreq/EPP

| Perfil | Governor solicitado | EPP solicitado, se anunciado |
|---|---|---|
| `balanced` | `schedutil` | `balance_performance`, senão `balance_power` |
| `performance` | `performance` | `performance` |
| `maximum` | `performance` | `performance` |
| `gaming` | `performance` | `performance` |
| `low-latency` | `performance` | `performance` |
| `power-saving` | `powersave` | `power`, senão `balance_power` |
| `custom` | somente `--governor NOME` | somente `--epp NOME` |

Os nomes são apenas alvos solicitados: o LAO confere `scaling_available_governors` e `energy_performance_available_preferences` em cada política. Se um valor não estiver na lista fornecida pelo próprio kernel, ele não será escrito.

**Exceções e limites:**

- `balanced` não força um governor alternativo caso `schedutil` não esteja disponível.
- `custom` sem `--governor`/`--epp` não modifica nada; valores customizados passam pela mesma validação de compatibilidade.
- EPP não é inferido a partir do fabricante. Só é utilizado quando os atributos existem e aceitam o perfil nominal escolhido.
- Se `power-profiles-daemon`, `tuned`, `tlp`, `auto-cpufreq`, `cpupower`, `laptop-mode` ou o controlador TUXEDO correspondente estiver ativo, o LAO não disputa o controle e pula as escritas CPU.
- A interface CPUFreq pode não existir em VMs, kernels configurados sem suporte, ou plataformas que utilizam outra API.
- A alteração é runtime e outro daemon ou reboot pode redefinir o valor.
- O governor `performance` não significa necessariamente frequência fixa máxima em todo driver.
- Boost, tensão, frequência mínima/máxima, SMT, C-states, afinidade, scheduler de processos e mitigadores não são modificados.

A documentação do kernel descreve CPUFreq como uma interface por política e apresenta `scaling_available_governors`/EPP como capacidades específicas do driver. Portanto, os perfis do LAO não presumem suporte uniforme entre máquinas. Veja `docs/RESEARCH.md`.

### Controles manuais de memória, armazenamento e rede

| Opção | Interface | Validação e escopo |
|---|---|---|
| `--vm-swappiness N` | `/proc/sys/vm/swappiness` | Inteiro 0–200; nenhum valor é inferido automaticamente |
| `--vm-vfs-cache-pressure N` | `/proc/sys/vm/vfs_cache_pressure` | Inteiro 0–1000; valor manual |
| `--vm-dirty-ratio N` | `/proc/sys/vm/dirty_ratio` | Inteiro 0–100; deve ser maior ou igual ao background ratio final |
| `--vm-dirty-background-ratio N` | `/proc/sys/vm/dirty_background_ratio` | Inteiro 0–100; não pode exceder o dirty ratio final |
| `--device DEV --io-scheduler NOME` | `/sys/block/DEV/queue/scheduler` | O dispositivo e o nome exato do scheduler devem existir; operação por dispositivo |
| `--tcp-congestion-control NOME` | `/proc/sys/net/ipv4/tcp_congestion_control` | O nome precisa constar em `tcp_available_congestion_control` |

`vm.swappiness` é uma ponderação relativa de custo de I/O, e o valor ideal depende do workload. O scheduler é uma escolha por fila/dispositivo, e a simples disponibilidade não prova que ele aumentará desempenho. A escolha de congestion control afeta conexões TCP novas, não sessões já abertas. O LAO não carrega módulos TCP, não instala pacotes e não persiste as alterações após reboot. Veja `docs/RESEARCH.md`.

### Segurança e rollback

As escritas permitidas do LAO limitam-se às interfaces CPUFreq `scaling_governor` e `energy_performance_preference`, à fila `/sys/block/DEV/queue/scheduler` do dispositivo indicado aos quatro sysctls VM allowlisted e ao sysctl TCP descrito acima.

Antes de cada escrita:

1. O atributo sysfs/procfs é verificado como arquivo regular, gravável e não-link.
2. O valor atual é lido.
3. Uma segunda leitura detecta alteração concorrente entre preparação e escrita.
4. A intenção é anexada a `/var/lib/lao/changes.tsv`.
5. O diário é sincronizado com `sync -f` antes da mutação.
6. A escrita ocorre e é lida novamente para verificação.

O diário é root-owned e modo `0600`; o diretório de estado é root-owned e modo `0700`. Os logs ficam sob `/var/lib/lao/logs/`.

O rollback:

- aceita somente módulos, tipos e caminhos previstos;
- valida políticas CPUFreq, scheduler por dispositivo sob `/sys/block/`, os quatro caminhos VM allowlisted e o caminho TCP `tcp_congestion_control`;
- valida formato dos valores;
- restaura somente quando o valor atual ainda coincide com o valor que o LAO pretendia escrever;
- preserva um valor externo divergente;
- é idempotente após restauração.

Se o processo cair após o registro e antes da escrita, rollback verá que o valor original continua presente e não fará alteração. Se cair após a escrita, o registro prévio permite avaliar a reversão.

Para scheduler de I/O, o diário armazena somente o scheduler selecionado, não a lista textual de opções que o kernel retorna entre colchetes. O diário não pode distinguir uma alteração externa que coincidentemente escreveu exatamente o mesmo valor que o LAO havia solicitado. Esse limite está documentado; o mecanismo reduz conflitos, mas não pode identificar a autoria de uma escrita idêntica.

## 6. Kernel Builder

O construtor usa somente uma árvore local indicada explicitamente. Não baixa fontes.

```bash
# Preparar configuração, como usuário normal (não root)
./lao --kernel-builder --kernel-source "$HOME/src/linux"

# Compilar preparação anterior, com consentimento explícito
./lao --kernel-build \
  --kernel-source "$HOME/src/linux" \
  --confirm-kernel-build \
  --jobs 4
```

A preparação:

- calcula uma impressão digital SHA-256 da árvore de fontes, incluindo conteúdo, modos de arquivos e diretórios e destinos de links simbólicos (exclui metadados internos `.git`); qualquer mudança detectada depois da preparação exige preparar novamente;
- escolhe config da fonte, `/proc/config.gz`, `/boot/config-$(uname -r)` ou árvore de módulos;
- preserva a configuração-base como `.config.baseline`;
- executa `make O=<build-dir> olddefconfig` em diretório separado;
- gera `.config.diff` e um plano;
- não usa `localmodconfig`, pois dispositivos desconectados ou futuros poderiam ser removidos.

A compilação exige confirmação explícita, dependências presentes e 15 GiB livres como limiar conservador. O cálculo padrão de jobs considera CPUs e RAM disponíveis, além de limites de cgroup v1/v2. `--jobs N` permite substituição explícita.

**Fora do escopo do builder:** personalização automática de opções Kconfig por microarquitetura (o construtor preserva a configuração-base e roda `olddefconfig`, sem inventar flags de desempenho), `modules_install`, `depmod`, criação de pacote, assinatura Secure Boot, initramfs, instalação em `/boot`, atualização do GRUB/systemd-boot e reboot. Esses passos variam por distro, bootloader, esquema de partição e política Secure Boot. Não use fontes de kernel sem confiar na origem e verificar sua integridade.

O builder recusa execução como root porque `make` executa código da árvore fornecida.

## 7. Benchmark

`--benchmark` executa amostras CPU com `sysbench` se já estiver instalado. Padrão: 3 amostras de 5 segundos, com quantidade de threads online visível ao processo. É possível selecionar de 1 a 10 amostras e de 3 a 60 segundos por amostra.

O resumo calcula média, mínimo, máximo, desvio padrão e coeficiente de variação. As threads são limitadas por cotas de CPU do cgroup quando detectáveis. Se a carga de 1 minuto estiver alta em relação às threads visíveis, o LAO avisa que a comparação pode estar contaminada.

O benchmark não executa testes de disco destrutivos, não mede rede e não afirma ganhos de otimização. Compare resultados sob mesma temperatura, versão do teste, governor/EPP, threads, plano energético e carga de fundo. `sysbench` ausente significa benchmark ignorado, não instalado.

## 8. Testes

```bash
bash tests/run.sh
```

A suíte inclui:

- normalização de perfis e detecção de família por tokens `ID_LIKE`;
- pré-avaliação de privilégios para não exigir root quando nenhum writer pode atuar;
- mapeamento governor/EPP;
- escrita rastreada com diário prévio;
- rollback de governor, EPP, scheduler de bloco, quatro sysctls VM e TCP congestion control;
- rollback repetido;
- preservação de alteração externa;
- rejeição de caminho adulterado;
- preparação Kbuild simulada por usuário não-root e preservação da configuração-fonte;
- validação de sintaxe Bash e chamadas de diagnóstico;
- escrita simulada dos três controles manuais, valores fora da faixa e nomes não anunciados;
- rollback dos controles manuais e preservação de alteração externa.

`--dry-run` não é uma camada universal de simulação. A CLI recusa combiná-lo com rollback, benchmark e Kernel Builder/build, que têm semânticas diferentes e não seriam transformados em operações simuladas.

ShellCheck e shfmt devem ser executados quando instalados:

```bash
shellcheck ./lao ./lib/*.sh ./tests/*.sh
shfmt -d ./lao ./lib/*.sh ./tests/*.sh
```

O relatório de execução disponível nesta distribuição está em `docs/TEST-REPORT.md`. Ele distingue testes reais no container, testes simulados e recursos ainda não testados. O histórico de alterações está em `CHANGELOG.md`.

## 9. Estado de implementação

| Subsistema | Estado na 1.4.0-alpha1 |
|---|---|
| Distro / package manager discovery | Implementado, somente detecção |
| CPU / topologia / vulnerabilidades | Diagnóstico |
| CPUFreq governor | Escrita runtime condicional |
| CPU EPP | Escrita runtime condicional |
| Conflitos com power managers | Detecção e bloqueio conservador |
| Kernel / config / cmdline | Diagnóstico |
| Kernel builder | Preparação e compilação local, sem instalação |
| Memória / PSI / ZRAM / ZSWAP / THP / NUMA | Diagnóstico ampliado; swappiness, vfs_cache_pressure e dirty ratios manuais e reversíveis (runtime) |
| Armazenamento / scheduler / TRIM / SMART | Diagnóstico; scheduler manual por dispositivo |
| GPU / DRM / Mesa / Vulkan / VA-API | Diagnóstico |
| Rede / TCP / qdisc / offload | Diagnóstico; congestion control manual e reversível |
| systemd / serviços | Diagnóstico |
| Desktop / boot / segurança | Diagnóstico |
| Backup / rollback | Implementado para governor, EPP, scheduler, sysctls VM selecionados e TCP congestion control (runtime; allowlist) |
| Benchmark CPU | Implementado condicional com sysbench |

Este estado é intencional. Não há benefício em modificar memória, armazenamento ou rede com números fixos sem conhecer carga real, dispositivo, topologia e requisitos de latência.

## 10. Licença

MIT. Consulte `LICENSE`.


## Auditoria e estado da versão intermediária

Consulte `docs/AUDIT-1.3.0.md` para a auditoria da base e `docs/IMPLEMENTATION-STATUS-1.4.0-alpha1.md` para o que foi acrescentado e o que continua pendente. Esta versão é alpha e não satisfaz o critério de conclusão integral do protocolo.
