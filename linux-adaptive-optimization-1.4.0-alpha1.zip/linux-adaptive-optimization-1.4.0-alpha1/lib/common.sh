#!/usr/bin/env bash
# Shared primitives for Linux Adaptive Optimization Engine (LAO).
# Minimum supported shell: Bash 4.4.

LAO_VERSION="1.4.0-alpha1"
LAO_NAME="Linux Adaptive Optimization Engine"
LAO_STATE_DIR="/var/lib/lao"
LAO_JOURNAL="${LAO_STATE_DIR}/changes.tsv"
LAO_LOG_FILE=""
LAO_RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)-$$"
LAO_LOCK_FD=""

if [[ -t 1 ]]; then
  C_RESET=$'\033[0m'; C_RED=$'\033[31m'; C_GREEN=$'\033[32m'
  C_YELLOW=$'\033[33m'; C_BLUE=$'\033[34m'; C_CYAN=$'\033[36m'
else
  C_RESET=""; C_RED=""; C_GREEN=""; C_YELLOW=""; C_BLUE=""; C_CYAN=""
fi

log() {
  local level="$1"; shift
  local color="$C_RESET" stamp message
  case "$level" in
    INFO) color="$C_CYAN" ;;
    OK) color="$C_GREEN" ;;
    WARN) color="$C_YELLOW" ;;
    ERROR) color="$C_RED" ;;
    STEP) color="$C_BLUE" ;;
  esac
  stamp="$(date -Is 2>/dev/null || date)"
  message="[$stamp][$level] $*"
  printf '%s%s%s\n' "$color" "$message" "$C_RESET"
  if [[ -n "$LAO_LOG_FILE" ]]; then
    printf '%s\n' "$message" >> "$LAO_LOG_FILE" 2>/dev/null || true
  fi
}

have() { command -v "$1" >/dev/null 2>&1; }

read_value() {
  local path="$1"
  [[ -r "$path" ]] || return 1
  cat -- "$path" 2>/dev/null
}

b64_encode() { printf '%s' "$1" | base64 | tr -d '\n'; }
b64_decode() { printf '%s' "$1" | base64 --decode 2>/dev/null; }

require_root() {
  if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    log ERROR "Esta operação altera o sistema e exige privilégios administrativos. Execute com sudo."
    return 1
  fi
}

init_state() {
  require_root || return 1
  umask 077
  if [[ -L "$LAO_STATE_DIR" ]]; then
    log ERROR "Diretório de estado é um link simbólico e foi recusado: $LAO_STATE_DIR"
    return 1
  fi
  if ! mkdir -p -- "$LAO_STATE_DIR"; then
    log ERROR "Não foi possível criar $LAO_STATE_DIR."
    return 1
  fi
  if [[ "$(stat -c '%u' "$LAO_STATE_DIR" 2>/dev/null || printf unknown)" != 0 ]]; then
    log ERROR "O diretório de estado não pertence ao root; recusando escrita por segurança."
    return 1
  fi
  chmod 700 "$LAO_STATE_DIR" || return 1
  if [[ -L "$LAO_JOURNAL" ]]; then
    log ERROR "Arquivo de diário é um link simbólico e foi recusado: $LAO_JOURNAL"
    return 1
  fi
  touch -- "$LAO_JOURNAL" || {
    log ERROR "Não foi possível preparar o diário de alterações."
    return 1
  }
  [[ "$(stat -c '%u' "$LAO_JOURNAL" 2>/dev/null || printf unknown)" == 0 ]] || {
    log ERROR "O diário de alterações não pertence ao root."; return 1;
  }
  chmod 600 "$LAO_JOURNAL" || return 1
}

init_run_log() {
  local log_dir="$LAO_STATE_DIR/logs"
  [[ ! -L "$log_dir" ]] || { log ERROR "Diretório de logs é um link simbólico; operação recusada."; return 1; }
  mkdir -p -- "$log_dir" || return 1
  [[ "$(stat -c '%u' "$log_dir" 2>/dev/null || printf unknown)" == 0 ]] || {
    log ERROR "Diretório de logs não pertence ao root."; return 1;
  }
  LAO_LOG_FILE="$log_dir/run-$LAO_RUN_ID.log"
  [[ ! -L "$LAO_LOG_FILE" ]] || { log ERROR "Arquivo de log já é link simbólico."; return 1; }
  (umask 077; : >> "$LAO_LOG_FILE") || return 1
  chmod 600 "$LAO_LOG_FILE" || return 1
}

acquire_lock() {
  require_root || return 1
  if have flock; then
    [[ -d /run/lock ]] || { log ERROR "/run/lock não está disponível."; return 1; }
    exec 9>/run/lock/lao.lock || return 1
    if ! flock -n 9; then
      log ERROR "Outra instância do LAO está executando uma operação de escrita."
      return 1
    fi
    LAO_LOCK_FD=9
  else
    local lockdir="/run/lock/lao.lock.d"
    if ! mkdir "$lockdir" 2>/dev/null; then
      log ERROR "Não foi possível adquirir o bloqueio ($lockdir). Verifique se outra instância está ativa."
      return 1
    fi
    LAO_LOCK_FD="$lockdir"
    trap 'rmdir -- "$LAO_LOCK_FD" 2>/dev/null || true' EXIT
  fi
}

# The journal is deliberately written BEFORE the sysfs write. A crash between
# the journal append and the write is harmless: rollback sees the original
# value and does not change it. A crash after the write remains recoverable.
journal_change() {
  local module="$1" type="$2" path="$3" before="$4" after="$5"
  local before64 after64
  before64="$(b64_encode "$before")"
  after64="$(b64_encode "$after")"
  [[ "$module$type$path" != *$'\t'* && "$module$type$path" != *$'\n'* ]] || return 1
  printf '%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$LAO_RUN_ID" "$module" "$type" "$path" "$before64" "$after64" >> "$LAO_JOURNAL" || return 1
  # Linux GNU coreutils supports sync -f to persist the journal file before
  # the kernel attribute is modified. Fail closed if it cannot be flushed.
  if ! sync -f "$LAO_JOURNAL" 2>/dev/null; then
    log ERROR "Não foi possível sincronizar o diário em disco; alteração cancelada."
    return 1
  fi
}

write_tracked_attribute() {
  local module="$1" type="$2" path="$3" desired="$4"
  local before current actual
  [[ "$type" == sysfs || "$type" == procfs ]] || {
    log ERROR "$module: tipo de atributo não permitido: $type"; return 2;
  }
  [[ -e "$path" && -f "$path" && -w "$path" && ! -L "$path" ]] || {
    log WARN "$module: interface indisponível, não regular ou somente leitura: $path"
    return 2
  }
  before="$(read_value "$path")" || return 2
  if [[ "$before" == "$desired" ]]; then
    log INFO "$module: $path já está em '$desired'; nenhuma alteração."
    return 0
  fi
  # Detect a competing writer between initial read and mutation.
  current="$(read_value "$path")" || return 2
  if [[ "$current" != "$before" ]]; then
    log WARN "$module: $path mudou durante a preparação; alteração cancelada."
    return 2
  fi
  if ! journal_change "$module" "$type" "$path" "$before" "$desired"; then
    log ERROR "$module: não foi possível registrar a intenção; nenhuma alteração foi aplicada."
    return 1
  fi
  if ! printf '%s\n' "$desired" > "$path" 2>/dev/null; then
    log WARN "$module: o kernel recusou a alteração de $path; intenção mantida no diário para auditoria."
    return 2
  fi
  actual="$(read_value "$path")" || actual=""
  if [[ "$actual" != "$desired" ]]; then
    log WARN "$module: verificação posterior divergiu (solicitado='$desired', observado='$actual'). Não sobrescrevendo valor divergente; o diário permite avaliar rollback."
    return 2
  fi
  log OK "$module: $path alterado de '$before' para '$actual'."
}

write_scheduler_tracked() {
  local module="$1" path="$2" desired="$3" before current actual
  [[ -e "$path" && -f "$path" && -w "$path" && ! -L "$path" ]] || {
    log WARN "$module: interface de scheduler indisponível ou somente leitura: $path"
    return 2
  }
  before="$(sed -n 's/.*\[\([^]]*\)\].*/\1/p' "$path" 2>/dev/null)"
  if [[ -z "$before" ]]; then
    before="$(cat "$path" 2>/dev/null || true)"
  fi
  [[ "$before" =~ ^[A-Za-z0-9_.+-]+$ ]] || {
    log WARN "$module: não foi possível identificar o scheduler ativo em $path; escrita recusada."
    return 2
  }
  if [[ "$before" == "$desired" ]]; then
    log INFO "$module: $path já está em '$desired'; nenhuma alteração."
    return 0
  fi
  current="$(sed -n 's/.*\[\([^]]*\)\].*/\1/p' "$path" 2>/dev/null)"
  [[ -n "$current" ]] || current="$(cat "$path" 2>/dev/null || true)"
  if [[ "$current" != "$before" ]]; then
    log WARN "$module: $path mudou durante a preparação; alteração cancelada."
    return 2
  fi
  journal_change "$module" sysfs "$path" "$before" "$desired" || {
    log ERROR "$module: não foi possível registrar a intenção; scheduler não alterado."
    return 1
  }
  if ! printf '%s\n' "$desired" > "$path" 2>/dev/null; then
    log WARN "$module: o kernel recusou o scheduler '$desired' em $path."
    return 2
  fi
  actual="$(sed -n 's/.*\[\([^]]*\)\].*/\1/p' "$path" 2>/dev/null)"
  [[ -n "$actual" ]] || actual="$(cat "$path" 2>/dev/null || true)"
  if [[ "$actual" != "$desired" ]]; then
    log WARN "$module: scheduler solicitado '$desired', observado '$actual'; sem nova escrita."
    return 2
  fi
  log OK "$module: scheduler alterado de '$before' para '$actual'."
}

write_sysfs_tracked() {
  write_tracked_attribute "$1" sysfs "$2" "$3"
}

module_header() {
  printf '\n%s\n' "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  log STEP "$1"
  printf '%s\n' "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

status_line() {
  local label="$1" value="$2"
  printf '  %-29s %s\n' "$label" "${value:-indisponível}"
}

normalize_profile() {
  case "${1,,}" in
    balanced) printf 'balanced' ;;
    performance) printf 'performance' ;;
    maximum|maximum-performance|max) printf 'maximum' ;;
    gaming) printf 'gaming' ;;
    low-latency|low_latency|latency) printf 'low-latency' ;;
    power-saving|power_saving|powersave) printf 'power-saving' ;;
    custom) printf 'custom' ;;
    *) return 1 ;;
  esac
}
