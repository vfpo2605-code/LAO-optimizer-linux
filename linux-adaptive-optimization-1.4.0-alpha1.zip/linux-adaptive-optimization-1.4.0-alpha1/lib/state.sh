#!/usr/bin/env bash
# Conflict-aware rollback for LAO-managed CPUFreq runtime attributes.

rollback_changes() {
  local module_filter="${1:-all}"
  local allowed_cpu_root="${2:-/sys/devices/system/cpu/cpufreq}"
  local allowed_block_root="${3:-/sys/block}"
  local allowed_net_path="${4:-/proc/sys/net/ipv4/tcp_congestion_control}"
  local allowed_vm_path="${5:-/proc/sys/vm/swappiness}"
  local allowed_vm_root="${6:-/proc/sys/vm}"
  local line run module type path before64 after64 before after current restored=0 skipped=0 relative attr
  local idx observed
  local -a journal_lines=()
  require_root || return 1
  [[ -r "$LAO_JOURNAL" && ! -L "$LAO_JOURNAL" ]] || {
    log WARN "Nenhum diário de alterações válido encontrado em $LAO_JOURNAL."
    return 0
  }
  mapfile -t journal_lines < "$LAO_JOURNAL"
  for (( idx=${#journal_lines[@]}-1; idx>=0; idx-- )); do
    line="${journal_lines[$idx]}"
    [[ -n "$line" ]] || continue
    IFS=$'\t' read -r run module type path before64 after64 <<< "$line"
    [[ "$module_filter" == all || "$module" == "$module_filter" ]] || continue

    attr=""
    case "$module:$type" in
      cpu:sysfs)
        if [[ "$path" == "$allowed_cpu_root"/* ]]; then
          relative="${path#"$allowed_cpu_root"/}"
          if [[ "$relative" =~ ^policy[0-9]+/scaling_governor$ ]]; then attr=governor
          elif [[ "$relative" =~ ^policy[0-9]+/energy_performance_preference$ ]]; then attr=epp; fi
        fi
        ;;
      storage:sysfs)
        if [[ "$path" == "$allowed_block_root"/* ]]; then
          relative="${path#"$allowed_block_root"/}"
          [[ "$relative" =~ ^[A-Za-z0-9._+-]+/queue/scheduler$ ]] && attr=scheduler
        fi
        ;;
      network:procfs)
        [[ "$path" == "$allowed_net_path" ]] && attr=tcp_congestion
        ;;
      memory:procfs)
        case "$path" in
          "$allowed_vm_path") attr=swappiness ;;
          "$allowed_vm_root/vfs_cache_pressure") attr=vfs_cache_pressure ;;
          "$allowed_vm_root/dirty_ratio") attr=dirty_ratio ;;
          "$allowed_vm_root/dirty_background_ratio") attr=dirty_background_ratio ;;
        esac
        ;;
    esac
    if [[ -z "$attr" ]]; then
      log WARN "Registro fora da lista de reversão permitida ignorado: $module / $type / $path"
      ((skipped += 1)) || true
      continue
    fi
    if [[ ! -e "$path" || ! -f "$path" || ! -w "$path" || -L "$path" || -L "${path%/*}" ]]; then
      log WARN "Rollback ignorado: interface ausente, não regular, link simbólico ou somente leitura: $path"
      ((skipped += 1)) || true
      continue
    fi
    if ! before="$(b64_decode "$before64")" || ! after="$(b64_decode "$after64")"; then
      log WARN "Registro com Base64 inválido ignorado para $path."
      ((skipped += 1)) || true
      continue
    fi
    case "$attr" in
      governor) [[ "$before" =~ ^[[:alnum:]_-]+$ && "$after" =~ ^[[:alnum:]_-]+$ ]] || attr=invalid ;;
      epp|scheduler|tcp_congestion) [[ "$before" =~ ^[[:alnum:]_.-]+$ && "$after" =~ ^[[:alnum:]_.-]+$ ]] || attr=invalid ;;
      swappiness)
        [[ "$before" =~ ^[0-9]+$ && "$after" =~ ^[0-9]+$ ]] && (( before <= 200 && after <= 200 )) || attr=invalid
        ;;
      vfs_cache_pressure)
        [[ "$before" =~ ^[0-9]+$ && "$after" =~ ^[0-9]+$ ]] && (( before <= 1000 && after <= 1000 )) || attr=invalid
        ;;
      dirty_ratio|dirty_background_ratio)
        [[ "$before" =~ ^[0-9]+$ && "$after" =~ ^[0-9]+$ ]] && (( before <= 100 && after <= 100 )) || attr=invalid
        ;;
    esac
    if [[ "$attr" == invalid ]]; then
      log WARN "Valor inválido no diário; registro ignorado para $path."
      ((skipped += 1)) || true
      continue
    fi
    if [[ "$attr" == scheduler ]]; then
      current="$(sed -n 's/.*\[\([^]]*\)\].*/\1/p' "$path" 2>/dev/null)"
      [[ -n "$current" ]] || current="$(read_value "$path")" || current=""
    else
      current="$(read_value "$path")" || current=""
    fi
    if [[ "$current" == "$before" ]]; then
      log INFO "Já restaurado: $path permanece em '$before'."
      ((skipped += 1)) || true
      continue
    fi
    if [[ "$current" != "$after" ]]; then
      log WARN "Conflito: $path mudou desde a aplicação (atual='$current', LAO esperava='$after'); preservado."
      ((skipped += 1)) || true
      continue
    fi
    if printf '%s\n' "$before" > "$path" 2>/dev/null; then
      if [[ "$attr" == scheduler ]]; then
        observed="$(sed -n 's/.*\[\([^]]*\)\].*/\1/p' "$path" 2>/dev/null)"
        [[ -n "$observed" ]] || observed="$(read_value "$path")" || observed=""
      else
        observed="$(read_value "$path")" || observed=""
      fi
    else
      observed=""
    fi
    if [[ "$observed" == "$before" ]]; then
      log OK "Restaurado: $path -> '$before' (registro $run / $module)."
      ((restored += 1)) || true
    else
      log ERROR "Falha ao restaurar $path."
      ((skipped += 1)) || true
    fi
  done
  log INFO "Rollback concluído: $restored restauração(ões), $skipped registro(s) preservado(s)/ignorados."
}
