#!/usr/bin/env bash
# Optimization modules. Write-capable controls are intentionally few and
# capability-gated; the rest remain read-only until a measured policy exists.

LAO_PROFILE="balanced"
LAO_DRY_RUN=0
LAO_CUSTOM_GOVERNOR=""
LAO_CUSTOM_EPP=""
LAO_VM_SWAPPINESS=""
LAO_VM_VFS_CACHE_PRESSURE=""
LAO_VM_DIRTY_RATIO=""
LAO_VM_DIRTY_BACKGROUND_RATIO=""
LAO_STORAGE_DEVICE=""
LAO_IO_SCHEDULER=""
LAO_TCP_CONGESTION=""

list_modules() {
  cat <<'MODULES'
Nome          Estado                       Escopo
cpu           aplicado/condicional        Governor CPUFreq e EPP anunciados pelo driver
kernel        diagnóstico                 Kernel, configuração, scheduler e preempção
memory        aplicado/manual              sysctls VM explicitamente escolhidos; ZRAM/THP/NUMA diagnóstico
storage       aplicado/manual              Scheduler de um dispositivo explicitamente escolhido
gpu          diagnóstico                 Drivers, DRM, Mesa, Vulkan, OpenGL e VA-API
network       aplicado/manual              TCP congestion control explicitamente escolhido
services      diagnóstico                 Serviços e dependências systemd (sem desativar)
desktop       diagnóstico                 Desktop Environment, sessão e display server
boot          diagnóstico                 Boot time, serviços lentos e kernel cmdline
security      diagnóstico                 Mitigações, Secure Boot, firewall e controles
kernel-builder limitado                   Build local em diretório O=; sem instalação
MODULES
}

profile_governor_target() {
  case "$LAO_PROFILE" in
    balanced) printf 'schedutil' ;;
    performance|maximum|gaming|low-latency) printf 'performance' ;;
    power-saving) printf 'powersave' ;;
    custom)
      [[ -n "$LAO_CUSTOM_GOVERNOR" ]] || return 1
      printf '%s' "$LAO_CUSTOM_GOVERNOR"
      ;;
    *) return 1 ;;
  esac
}

profile_epp_target() {
  local available="$1" candidate
  local -a candidates=()
  case "$LAO_PROFILE" in
    balanced) candidates=(balance_performance balance_power) ;;
    performance|maximum|gaming|low-latency) candidates=(performance) ;;
    power-saving) candidates=(power balance_power) ;;
    custom)
      [[ -n "$LAO_CUSTOM_EPP" ]] || return 1
      candidates=("$LAO_CUSTOM_EPP")
      ;;
    *) return 1 ;;
  esac
  for candidate in "${candidates[@]}"; do
    if [[ " $available " == *" $candidate "* ]]; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  return 1
}

apply_vm_swappiness() {
  local value="$1" path="${2:-/proc/sys/vm/swappiness}" value_num current
  if [[ ! "$value" =~ ^[0-9]{1,3}$ ]]; then
    log ERROR "--vm-swappiness exige um inteiro entre 0 e 200."
    return 2
  fi
  value_num=$((10#$value))
  if (( value_num > 200 )); then
    log ERROR "vm.swappiness aceita somente valores de 0 a 200."
    return 2
  fi
  value="$value_num"
  if [[ ! -r "$path" || ! -w "$path" ]]; then
    log WARN "A interface $path não está disponível para leitura e escrita; nenhum ajuste aplicado."
    return 2
  fi
  current="$(cat "$path" 2>/dev/null || true)"
  if (( LAO_DRY_RUN )); then
    log INFO "DRY-RUN: vm.swappiness $current -> $value."
    return 0
  fi
  write_tracked_attribute memory procfs "$path" "$value"
}


apply_vm_tunable() {
  local name="$1" value="$2" root="${3:-/proc/sys/vm}" path current max=1000
  case "$name" in
    swappiness) max=200 ;;
    vfs_cache_pressure) max=1000 ;;
    dirty_ratio|dirty_background_ratio) max=100 ;;
    *) log ERROR "Parâmetro VM não permitido: $name"; return 2 ;;
  esac
  [[ "$value" =~ ^[0-9]{1,4}$ ]] || { log ERROR "$name exige um inteiro não negativo."; return 2; }
  value=$((10#$value))
  (( value <= max )) || { log ERROR "$name excede o limite conservador validado (0-$max)."; return 2; }
  path="$root/$name"
  [[ -r "$path" && ! -L "$path" ]] || { log WARN "Interface VM indisponível para leitura: $path"; return 2; }
  if (( ! LAO_DRY_RUN )) && [[ ! -w "$path" ]]; then
    log WARN "Interface VM não gravável: $path"
    return 2
  fi
  current="$(cat "$path" 2>/dev/null || true)"
  [[ "$current" =~ ^[0-9]+$ ]] || { log WARN "Valor atual inválido ou não numérico em $path"; return 2; }
  if [[ "$name" == dirty_ratio ]]; then
    local bg
    bg="${LAO_VM_DIRTY_BACKGROUND_RATIO:-$(cat "$root/dirty_background_ratio" 2>/dev/null || printf 0)}"
    [[ "$bg" =~ ^[0-9]+$ ]] && (( bg <= value )) || { log ERROR "dirty_background_ratio ($bg) não pode exceder dirty_ratio ($value)."; return 2; }
  elif [[ "$name" == dirty_background_ratio ]]; then
    local dirty
    dirty="${LAO_VM_DIRTY_RATIO:-$(cat "$root/dirty_ratio" 2>/dev/null || printf 0)}"
    [[ "$dirty" =~ ^[0-9]+$ ]] && (( value <= dirty )) || { log ERROR "dirty_background_ratio ($value) não pode exceder dirty_ratio ($dirty)."; return 2; }
  fi
  if (( LAO_DRY_RUN )); then
    log INFO "DRY-RUN: vm.$name $current -> $value (runtime; não persistente)."
    return 0
  fi
  write_tracked_attribute memory procfs "$path" "$value"
}

apply_storage_scheduler() {
  local device="$1" requested="$2" block_root="${3:-/sys/block}"
  local queue_file choices current
  if [[ ! "$device" =~ ^[A-Za-z0-9._+-]+$ || ! "$requested" =~ ^[A-Za-z0-9._+-]+$ ]]; then
    log ERROR "Nome de dispositivo ou scheduler contém caracteres não permitidos."
    return 2
  fi
  queue_file="$block_root/$device/queue/scheduler"
  if [[ ! -r "$queue_file" || ! -w "$queue_file" || -L "$queue_file" ]]; then
    log WARN "Scheduler de I/O indisponível ou não gravável para '$device': $queue_file."
    return 2
  fi
  choices="$(tr -d '[]' < "$queue_file" 2>/dev/null || true)"
  current="$(sed -n 's/.*\[\([^]]*\)\].*/\1/p' "$queue_file" 2>/dev/null || true)"
  if [[ " $choices " != *" $requested "* ]]; then
    log WARN "Scheduler '$requested' não está anunciado para $device. Disponíveis: ${choices:-indisponíveis}. Nada foi alterado."
    return 2
  fi
  if [[ -z "$current" ]]; then
    log WARN "Não foi possível identificar o scheduler atual de $device; alteração recusada."
    return 2
  fi
  if [[ "$current" == "$requested" ]]; then
    log INFO "$device já utiliza o scheduler '$requested'."
    return 0
  fi
  if (( LAO_DRY_RUN )); then
    log INFO "DRY-RUN: $device scheduler '$current' -> '$requested'."
    return 0
  fi
  write_scheduler_tracked storage "$queue_file" "$requested"
}

apply_tcp_congestion() {
  local requested="$1" path="${2:-/proc/sys/net/ipv4/tcp_congestion_control}"
  local available_path="${3:-/proc/sys/net/ipv4/tcp_available_congestion_control}" available current
  if [[ ! "$requested" =~ ^[A-Za-z0-9_.-]+$ ]]; then
    log ERROR "Nome de algoritmo TCP contém caracteres não permitidos."
    return 2
  fi
  available="$(cat "$available_path" 2>/dev/null || true)"
  if [[ ! -r "$path" || ! -w "$path" ]]; then
    log WARN "Interface TCP congestion control indisponível ou não gravável; nenhuma alteração aplicada."
    return 2
  fi
  if [[ " $available " != *" $requested "* ]]; then
    log WARN "Algoritmo TCP '$requested' não está anunciado pelo kernel. Disponíveis: ${available:-indisponíveis}."
    return 2
  fi
  current="$(cat "$path" 2>/dev/null || true)"
  if [[ "$current" == "$requested" ]]; then
    log INFO "TCP congestion control já está em '$requested'."
    return 0
  fi
  if (( LAO_DRY_RUN )); then
    log INFO "DRY-RUN: TCP congestion control '$current' -> '$requested'."
    return 0
  fi
  write_tracked_attribute network procfs "$path" "$requested"
}

optimization_may_write() {
  local cpu_root="${1:-/sys/devices/system/cpu/cpufreq}" manager policy available current desired epp_available epp_current desired_epp
  [[ -n "$LAO_VM_SWAPPINESS" || -n "$LAO_VM_VFS_CACHE_PRESSURE" || -n "$LAO_VM_DIRTY_RATIO" || -n "$LAO_VM_DIRTY_BACKGROUND_RATIO" || -n "$LAO_STORAGE_DEVICE" || -n "$LAO_TCP_CONGESTION" ]] && return 0
  [[ -z "${CUSTOM_GOVERNOR:-}" && -z "${CUSTOM_EPP:-}" ]] || return 0
  [[ -z "${SELECTED_MODULE:-}" || "${SELECTED_MODULE:-}" == cpu ]] || return 1
  manager="$(active_cpu_policy_managers)"
  [[ -z "$manager" ]] || return 1
  desired="$(profile_governor_target 2>/dev/null || true)"
  for policy in "$cpu_root"/policy[0-9]*; do
    [[ -d "$policy" ]] || continue
    available="$(cat "$policy/scaling_available_governors" 2>/dev/null || true)"
    current="$(cat "$policy/scaling_governor" 2>/dev/null || true)"
    if [[ -n "$desired" && " $available " == *" $desired "* && "$current" != "$desired" ]]; then
      return 0
    fi
    epp_available="$(cat "$policy/energy_performance_available_preferences" 2>/dev/null || true)"
    epp_current="$(cat "$policy/energy_performance_preference" 2>/dev/null || true)"
    desired_epp="$(profile_epp_target "$epp_available" 2>/dev/null || true)"
    if [[ -n "$desired_epp" && "$epp_current" != "$desired_epp" && -n "$epp_current" ]]; then
      return 0
    fi
  done
  return 1
}

active_cpu_policy_managers() {
  local unit manager
  local -a managers=(power-profiles-daemon.service tuned.service tlp.service auto-cpufreq.service cpupower.service laptop-mode.service tuxedo-control-center.service tuxedo-control-center-daemon.service)
  local -a active=()
  if have systemctl && [[ -d /run/systemd/system ]]; then
    for unit in "${managers[@]}"; do
      systemctl is-active --quiet "$unit" 2>/dev/null && active+=("$unit")
    done
  fi
  if have pgrep; then
    for manager in auto-cpufreq tlp; do
      pgrep -x "$manager" >/dev/null 2>&1 && active+=("process:$manager")
    done
  fi
  printf '%s' "${active[*]:-}"
}

cpu_module() {
  module_header "CPU PERFORMANCE ENGINE"
  if have lscpu; then
    lscpu 2>/dev/null | grep -E '^(Architecture|CPU op-mode|Vendor ID|CPU family|Model:|Model name|Stepping|CPU\(s\)|On-line CPU|Thread\(s\) per core|Core\(s\) per socket|Socket\(s\)|NUMA node|L1d cache|L1i cache|L2 cache|L3 cache|Flags):' | head -n 42 || true
  fi
  cpu_capability_report
  [[ "${LAO_ACTION:-analyze}" == optimize ]] || return 0
  if [[ "$LAO_PROFILE" == custom && -z "$LAO_CUSTOM_GOVERNOR" && -z "$LAO_CUSTOM_EPP" ]]; then
    log WARN "Perfil custom sem --governor/--epp definidos; nenhuma escrita será realizada."
    return 0
  fi

  local desired_governor policy available current driver desired_epp epp_available epp_current manager_conflicts
  local policies=0 changes=0
  desired_governor="$(profile_governor_target)" || desired_governor=""
  manager_conflicts="$(active_cpu_policy_managers)"
  if [[ -n "$manager_conflicts" && "${LAO_ACTION:-analyze}" == optimize ]]; then
    log WARN "Gerenciador(es) de energia ativo(s): $manager_conflicts. LAO não disputará governor/EPP com outro controlador; nenhuma escrita CPU será feita."
    return 0
  fi
  for policy in /sys/devices/system/cpu/cpufreq/policy[0-9]*; do
    [[ -d "$policy" ]] || continue
    ((policies += 1)) || true
    driver="$(cat "$policy/scaling_driver" 2>/dev/null || printf unknown)"
    available="$(cat "$policy/scaling_available_governors" 2>/dev/null || true)"
    current="$(cat "$policy/scaling_governor" 2>/dev/null || true)"

    if [[ -n "$desired_governor" ]]; then
      if [[ " $available " != *" $desired_governor "* ]]; then
        log WARN "${policy##*/} ($driver): governor '$desired_governor' não está disponível (atual: ${current:-desconhecido}); preservado."
      elif [[ "${LAO_ACTION:-analyze}" == optimize && "$current" != "$desired_governor" ]]; then
        if (( LAO_DRY_RUN )); then
          log INFO "DRY-RUN: ${policy##*/}: governor '$current' -> '$desired_governor'."
        elif write_sysfs_tracked cpu "$policy/scaling_governor" "$desired_governor"; then
          ((changes += 1)) || true
        fi
      else
        log INFO "${policy##*/}: governor atual '$current' compatível com perfil ou já aplicado."
      fi
    fi

    # EPP is a separate hint, not a frequency limit. It is applied only when
    # the kernel exposes both the writable value and the exact accepted name.
    epp_available="$(cat "$policy/energy_performance_available_preferences" 2>/dev/null || true)"
    epp_current="$(cat "$policy/energy_performance_preference" 2>/dev/null || true)"
    if [[ -n "$epp_available" && -r "$policy/energy_performance_preference" && -w "$policy/energy_performance_preference" ]]; then
      desired_epp="$(profile_epp_target "$epp_available")" || desired_epp=""
      if [[ -z "$desired_epp" ]]; then
        log INFO "${policy##*/} ($driver): nenhuma preferência EPP nominal compatível com o perfil foi anunciada; preservada."
      elif [[ "$epp_current" == "$desired_epp" ]]; then
        log INFO "${policy##*/}: EPP já está em '$epp_current'."
      elif (( LAO_DRY_RUN )); then
        log INFO "DRY-RUN: ${policy##*/}: EPP '$epp_current' -> '$desired_epp'."
      else
        if write_sysfs_tracked cpu "$policy/energy_performance_preference" "$desired_epp"; then
          ((changes += 1)) || true
        else
          log WARN "${policy##*/}: EPP não alterado. O driver/firmware pode impor restrições ou outro gerenciador pode controlar a política."
        fi
      fi
    else
      log INFO "${policy##*/}: EPP não exposto como interface gravável; nenhum parâmetro equivalente foi presumido."
    fi
  done

  if (( policies == 0 )); then
    log WARN "CPUFreq não expõe políticas em /sys/devices/system/cpu/cpufreq; nenhum ajuste aplicado."
  elif (( LAO_DRY_RUN )); then
    log INFO "Plano CPU concluído sem alterações (dry-run)."
  elif (( changes == 0 )); then
    log INFO "Nenhuma política foi modificada: os valores já coincidiam ou não havia interface compatível."
  else
    log OK "CPU: $changes atributo(s) de política alterado(s)."
  fi
  log INFO "Frequências mínimas/máximas, boost, tensão, SMT, C-states, afinidade e mitigadores térmicos permanecem intactos."
}

kernel_module() {
  module_header "KERNEL PERFORMANCE ENGINE"
  status_line "Kernel em execução" "$(uname -r)"
  status_line "Arquitetura" "$(uname -m)"
  status_line "Flavor identificado" "$LAO_KERNEL_FLAVOR"
  status_line "Linha de comando" "$(cat /proc/cmdline 2>/dev/null)"
  if have lscpu; then
    lscpu 2>/dev/null | grep -E '^(Architecture|CPU\(s\)|Thread|Core|Socket|NUMA|Virtualization|Hypervisor vendor):' || true
  fi
  local cfg="" reader
  [[ -r /proc/config.gz ]] && cfg="/proc/config.gz"
  [[ -z "$cfg" && -r "/boot/config-$(uname -r)" ]] && cfg="/boot/config-$(uname -r)"
  [[ -z "$cfg" && -r "/lib/modules/$(uname -r)/build/.config" ]] && cfg="/lib/modules/$(uname -r)/build/.config"
  if [[ -n "$cfg" ]]; then
    reader=cat; [[ "$cfg" == *.gz ]] && reader=zcat
    if have "$reader"; then
      status_line "Configuração do kernel" "$cfg"
      "$reader" "$cfg" 2>/dev/null | grep -E '^CONFIG_(PREEMPT|HZ=|NO_HZ|SCHED|CPU_FREQ|CPU_FREQ_GOV|NUMA|RCU|HZ_PERIODIC|HZ_1000|HZ_300|HZ_250)' | head -n 70 || true
    fi
  else
    log WARN "Configuração do kernel atual não está acessível; opções de compilação não verificadas."
  fi
  log INFO "CFS/EEVDF e detalhes do scheduler dependem da versão/configuração do kernel; LAO não troca scheduler nem parâmetros de boot automaticamente."
}

memory_module() {
  module_header "MEMORY MANAGEMENT ENGINE"
  status_line "RAM instalada" "$(format_kib "$LAO_RAM_KB")"
  status_line "RAM disponível" "$(format_kib "$LAO_RAM_AVAILABLE_KB")"
  status_line "Swap total" "$(format_kib "$LAO_SWAP_KB")"
  local file zram node failed=0
  for file in /proc/sys/vm/swappiness /proc/sys/vm/vfs_cache_pressure /proc/sys/vm/dirty_ratio /proc/sys/vm/dirty_background_ratio /proc/sys/vm/min_free_kbytes /proc/sys/vm/compaction_proactiveness /proc/sys/vm/watermark_scale_factor; do
    [[ -r "$file" ]] && status_line "${file##*/}" "$(cat "$file" 2>/dev/null)"
  done
  printf '\nPressão de memória (PSI):\n'
  [[ -r /proc/pressure/memory ]] && cat /proc/pressure/memory || log INFO "PSI de memória indisponível."
  printf '\nTransparent Huge Pages:\n'
  for file in /sys/kernel/mm/transparent_hugepage/enabled /sys/kernel/mm/transparent_hugepage/defrag /sys/kernel/mm/transparent_hugepage/shmem_enabled /sys/kernel/mm/transparent_hugepage/khugepaged/defrag; do
    [[ -r "$file" ]] && status_line "${file#/sys/kernel/mm/transparent_hugepage/}" "$(cat "$file" 2>/dev/null)"
  done
  printf '\nZRAM:\n'
  if have zramctl; then zramctl --output-all 2>/dev/null || zramctl 2>/dev/null || true; fi
  for zram in /sys/block/zram*; do
    [[ -d "$zram" ]] || continue
    printf '  %s\n' "${zram##*/}"
    for file in comp_algorithm disksize mem_limit backing_dev mm_stat io_stat; do
      [[ -r "$zram/$file" ]] && printf '    %-18s %s\n' "$file" "$(cat "$zram/$file" 2>/dev/null)"
    done
  done
  printf '\nZswap:\n'
  for file in /sys/module/zswap/parameters/enabled /sys/module/zswap/parameters/max_pool_percent /sys/module/zswap/parameters/compressor /sys/module/zswap/parameters/zpool; do
    [[ -r "$file" ]] && status_line "${file##*/}" "$(cat "$file" 2>/dev/null)"
  done
  printf '\nNUMA:\n'
  if [[ -d /sys/devices/system/node ]]; then
    for node in /sys/devices/system/node/node[0-9]*; do
      [[ -d "$node" ]] || continue
      printf '  %s CPUs=%s meminfo=%s\n' "${node##*/}" "$(cat "$node/cpulist" 2>/dev/null || printf '?')" "$(awk '/MemTotal/ {print $4, $5; exit}' "$node/meminfo" 2>/dev/null || printf '?')"
      [[ -r "$node/distance" ]] && printf '    distance=%s\n' "$(cat "$node/distance")"
    done
  else log INFO "Topologia NUMA não exposta."; fi
  if have swapon; then swapon --show --bytes 2>/dev/null || true; fi
  if [[ "${LAO_ACTION:-analyze}" == optimize ]]; then
    if [[ -n "$LAO_VM_SWAPPINESS" ]] && ! apply_vm_tunable swappiness "$LAO_VM_SWAPPINESS"; then failed=1; fi
    if [[ -n "$LAO_VM_VFS_CACHE_PRESSURE" ]] && ! apply_vm_tunable vfs_cache_pressure "$LAO_VM_VFS_CACHE_PRESSURE"; then failed=1; fi
    if [[ -n "$LAO_VM_DIRTY_RATIO" ]] && ! apply_vm_tunable dirty_ratio "$LAO_VM_DIRTY_RATIO"; then failed=1; fi
    if [[ -n "$LAO_VM_DIRTY_BACKGROUND_RATIO" ]] && ! apply_vm_tunable dirty_background_ratio "$LAO_VM_DIRTY_BACKGROUND_RATIO"; then failed=1; fi
    log WARN "Parâmetros VM são runtime, dependem do workload e não são persistidos. ZRAM, ZSWAP, THP e NUMA permanecem somente em diagnóstico nesta versão."
    (( failed == 0 )) || { log ERROR "Uma ou mais alterações de memória falharam; operação não será declarada bem-sucedida."; return 1; }
  else
    log INFO "Diagnóstico de memória ampliado. Nenhum ajuste de ZRAM, ZSWAP, THP, NUMA, reclaim ou writeback é aplicado automaticamente."
  fi
}

storage_module() {
  module_header "STORAGE I/O ENGINE"
  storage_capability_report
  if have findmnt; then
    printf '\nMontagens relevantes:\n'
    findmnt -rn -o SOURCE,TARGET,FSTYPE,OPTIONS 2>/dev/null | head -n 40 || true
  fi
  if have fstrim; then status_line "fstrim" "$(fstrim --version 2>/dev/null | head -n1)"; fi
  if have systemctl && [[ -d /run/systemd/system ]]; then
    status_line "fstrim.timer" "$(systemctl is-enabled fstrim.timer 2>/dev/null || printf indisponível) / $(systemctl is-active fstrim.timer 2>/dev/null || printf inativo)"
  fi
  if have nvme; then nvme list 2>/dev/null | head -n 24 || true; fi
  if have smartctl; then smartctl --scan 2>/dev/null | head -n 24 || true; fi
  local block file
  for block in /sys/block/*; do
    [[ -d "$block/queue" ]] || continue
    printf '\nFila de %s:\n' "${block##*/}"
    for file in rotational scheduler read_ahead_kb nr_requests max_sectors_kb write_cache discard_max_bytes; do
      [[ -r "$block/queue/$file" ]] && status_line "$file" "$(cat "$block/queue/$file" 2>/dev/null)"
    done
    for file in /sys/class/block/"${block##*/}"/device/power/control /sys/class/block/"${block##*/}"/device/power/runtime_status; do
      [[ -r "$file" ]] && status_line "${file##*/}" "$(cat "$file" 2>/dev/null)"
    done
  done
  for file in /sys/module/nvme_core/parameters/default_ps_max_latency_us; do
    [[ -r "$file" ]] && status_line "NVMe APST default_ps_max_latency_us" "$(cat "$file" 2>/dev/null)"
  done
  if [[ "${LAO_ACTION:-analyze}" == optimize && -n "$LAO_STORAGE_DEVICE" && -n "$LAO_IO_SCHEDULER" ]]; then
    apply_storage_scheduler "$LAO_STORAGE_DEVICE" "$LAO_IO_SCHEDULER" || log WARN "A solicitação de scheduler foi recusada ou não aplicada."
  else
    log INFO "Nenhum scheduler, readahead, mount option, política NVMe ou TRIM foi modificado. Use --device NOME --io-scheduler NOME para uma seleção explícita."
  fi
}

gpu_module() {
  module_header "GPU PERFORMANCE ENGINE"
  status_line "GPU(s)" "$LAO_GPU_SUMMARY"
  if have lspci; then lspci -nnk 2>/dev/null | grep -A3 -Ei 'VGA compatible controller|3D controller|Display controller' || true; fi
  if have glxinfo; then glxinfo -B 2>/dev/null | sed -n '1,18p' || true; fi
  if have vulkaninfo; then vulkaninfo --summary 2>/dev/null | sed -n '1,22p' || true; fi
  if have vainfo; then vainfo 2>&1 | sed -n '1,22p' || true; fi
  if have nvidia-smi; then nvidia-smi 2>/dev/null | head -n 18 || true; fi
  local card file driver
  for card in /sys/class/drm/card[0-9]*; do
    [[ -e "$card/device" ]] || continue
    driver="$(basename "$(readlink -f "$card/device/driver" 2>/dev/null)" 2>/dev/null || printf unknown)"
    printf '\nDRM %s driver=%s\n' "${card##*/}" "$driver"
    for file in vendor device subsystem_vendor subsystem_device power/control power/runtime_status gt_cur_freq_mhz gt_max_freq_mhz pp_dpm_sclk pp_dpm_mclk; do
      [[ -r "$card/device/$file" ]] && status_line "$file" "$(cat "$card/device/$file" 2>/dev/null)"
    done
  done
  log INFO "Nenhum driver, variável Mesa, módulo gráfico, clock ou power state de GPU foi alterado."
}

network_module() {
  module_header "NETWORK PERFORMANCE ENGINE"
  if have ip; then ip -brief address 2>/dev/null || true; ip -s link 2>/dev/null | head -n 52 || true; fi
  local file
  for file in /proc/sys/net/ipv4/tcp_congestion_control /proc/sys/net/ipv4/tcp_available_congestion_control /proc/sys/net/core/rmem_max /proc/sys/net/core/wmem_max /proc/sys/net/ipv4/ip_local_port_range; do
    [[ -r "$file" ]] && status_line "${file##*/}" "$(cat "$file")"
  done
  if have tc; then tc qdisc show 2>/dev/null || true; fi
  if have ethtool && have ip; then
    local iface
    while IFS= read -r iface; do
      [[ "$iface" == lo ]] && continue
      printf '\nInterface %s (features):\n' "$iface"
      ethtool -i "$iface" 2>/dev/null | head -n 10 || true
      ethtool -k "$iface" 2>/dev/null | head -n 35 || true
      ethtool -g "$iface" 2>/dev/null | head -n 18 || true
      ethtool -c "$iface" 2>/dev/null | head -n 18 || true
      ethtool -l "$iface" 2>/dev/null | head -n 18 || true
    done < <(ip -o link show | awk -F': ' '{print $2}' | cut -d@ -f1)
  fi
  if [[ "${LAO_ACTION:-analyze}" == optimize && -n "$LAO_TCP_CONGESTION" ]]; then
    apply_tcp_congestion "$LAO_TCP_CONGESTION" || log WARN "A solicitação de algoritmo TCP foi recusada ou não aplicada."
    log WARN "A troca do algoritmo TCP afeta conexões TCP novas; não altera MTU, buffers, qdisc, DNS ou IPv6."
  else
    log INFO "MTU, offloading, buffers, congestion control, DNS e IPv6 permanecem intactos. Use --tcp-congestion-control NOME para selecionar explicitamente um algoritmo anunciado."
  fi
}

services_module() {
  module_header "SYSTEMD E SERVIÇOS"
  if [[ ! -d /run/systemd/system ]] || ! have systemctl; then
    log WARN "systemd não está ativo ou systemctl não está disponível."
    return 0
  fi
  systemctl --failed --no-pager 2>/dev/null || true
  printf '\nSockets ativos (amostra):\n'
  systemctl list-units --type=socket --state=active --no-pager 2>/dev/null | head -n 24 || true
  printf '\nTimers ativos (amostra):\n'
  systemctl list-timers --all --no-pager 2>/dev/null | head -n 24 || true
  printf '\nUnidades habilitadas (amostra):\n'
  systemctl list-unit-files --state=enabled --no-pager 2>/dev/null | head -n 55 || true
  log INFO "Nenhum serviço será desativado, mascarado, parado ou reiniciado."
}

desktop_module() {
  module_header "DESKTOP E RESPONSIVIDADE"
  status_line "Desktop" "$LAO_DE"
  status_line "Display server" "$LAO_DISPLAY"
  status_line "Session type" "${XDG_SESSION_TYPE:-indisponível}"
  status_line "Wayland display" "${WAYLAND_DISPLAY:-indisponível}"
  status_line "X11 display" "${DISPLAY:-indisponível}"
  status_line "Session desktop" "${XDG_SESSION_DESKTOP:-indisponível}"
  log INFO "Animações, compositor, efeitos, configurações KDE/GNOME e preferências visuais não serão alterados."
}

boot_module() {
  module_header "BOOT PERFORMANCE ENGINE"
  if have systemd-analyze && [[ -d /run/systemd/system ]]; then
    systemd-analyze time 2>/dev/null || true
    printf '\nPrincipais unidades de inicialização:\n'
    systemd-analyze blame 2>/dev/null | head -n 18 || true
    systemd-analyze critical-chain 2>/dev/null | head -n 22 || true
  else
    log WARN "systemd-analyze indisponível; tempo detalhado de boot não foi obtido."
  fi
  status_line "Kernel cmdline" "$(cat /proc/cmdline 2>/dev/null)"
  local tool
  for tool in grub-mkconfig grub2-mkconfig bootctl limine efibootmgr mkinitcpio dracut update-initramfs; do
    have "$tool" && status_line "Ferramenta $tool" "$(command -v "$tool")"
  done
  [[ -r /etc/default/grub ]] && status_line "Config GRUB" "/etc/default/grub presente"
  [[ -d /boot/loader/entries ]] && status_line "systemd-boot entries" "$(find /boot/loader/entries -maxdepth 1 -type f 2>/dev/null | wc -l) arquivo(s)"
  [[ -d /boot/limine ]] && status_line "Limine" "/boot/limine presente"
  if [[ -d /sys/firmware/efi ]]; then status_line "Firmware" "UEFI"
  else status_line "Firmware" "BIOS/Legacy ou EFI não exposto"; fi
  log INFO "Initramfs, bootloader, entradas de boot e parâmetros do kernel não serão alterados."
}

security_module() {
  module_header "SECURITY AND STABILITY ENGINE"
  local file
  if [[ -d /sys/devices/system/cpu/vulnerabilities ]]; then
    for file in /sys/devices/system/cpu/vulnerabilities/*; do
      [[ -r "$file" ]] && status_line "${file##*/}" "$(cat "$file" 2>/dev/null)"
    done
  else log WARN "Interfaces de mitigação de CPU indisponíveis."; fi
  if have mokutil; then mokutil --sb-state 2>/dev/null || true
  elif [[ -d /sys/firmware/efi/efivars ]]; then log INFO "Secure Boot: efivars presente; estado exato não verificado sem mokutil."; fi
  if have firewall-cmd; then status_line "firewalld" "$(firewall-cmd --state 2>/dev/null || printf não-detectado)"; fi
  if have ufw; then ufw status 2>/dev/null | head -n 5 || true; fi
  if have systemctl && [[ -d /run/systemd/system ]]; then
    status_line "UFW service" "$(systemctl is-active ufw 2>/dev/null || printf não-detectado)"
    status_line "firewalld service" "$(systemctl is-active firewalld 2>/dev/null || printf não-detectado)"
  fi
  log OK "Mitigações, proteções térmicas, isolamento e firewall não serão enfraquecidos."
}

run_module() {
  local module="$1"
  case "$module" in
    cpu) cpu_module ;;
    kernel) kernel_module ;;
    memory) memory_module ;;
    storage) storage_module ;;
    gpu) gpu_module ;;
    network) network_module ;;
    services) services_module ;;
    desktop) desktop_module ;;
    boot) boot_module ;;
    security) security_module ;;
    *) log ERROR "Módulo desconhecido: $module"; return 2 ;;
  esac
}

run_all_modules() {
  local module failed=0
  for module in cpu kernel memory storage gpu network services desktop boot security; do
    run_module "$module" || failed=1
  done
  (( failed == 0 ))
}
