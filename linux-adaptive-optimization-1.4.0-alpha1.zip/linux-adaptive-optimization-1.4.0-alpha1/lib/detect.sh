#!/usr/bin/env bash
# Read-only host inventory and runtime capability discovery.

LAO_OS_ID="unknown"
LAO_OS_LIKE=""
LAO_OS_NAME="unknown"
LAO_OS_VERSION="unknown"
LAO_DISTRO_FAMILY="unknown"
LAO_PKG_MANAGER="unknown"
LAO_VIRT="physical-or-unknown"
LAO_CPU_MODEL="unknown"
LAO_CPU_VENDOR="unknown"
LAO_CPU_ARCH="$(uname -m 2>/dev/null || printf unknown)"
LAO_CPU_THREADS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || printf 1)"
LAO_RAM_KB="0"
LAO_RAM_AVAILABLE_KB="0"
LAO_SWAP_KB="0"
LAO_GPU_SUMMARY="não identificada"
LAO_DE="${XDG_CURRENT_DESKTOP:-${XDG_SESSION_DESKTOP:-unknown}}"
LAO_DISPLAY="${XDG_SESSION_TYPE:-unknown}"
LAO_INIT="unknown"
LAO_KERNEL_FLAVOR="unknown"
LAO_KERNEL_INSTALLED=""

os_like_has() {
  local wanted="$1" token
  for token in $LAO_OS_LIKE; do
    [[ "$token" == "$wanted" ]] && return 0
  done
  return 1
}

load_os_release() {
  local file="${1:-/etc/os-release}"
  [[ -r "$file" ]] || return 0
  # os-release is explicitly shell-compatible by its specification.
  # shellcheck disable=SC1091
  . "$file"
  LAO_OS_ID="${ID:-unknown}"
  LAO_OS_LIKE="${ID_LIKE:-}"
  LAO_OS_NAME="${PRETTY_NAME:-${NAME:-unknown}}"
  LAO_OS_VERSION="${VERSION_ID:-unknown}"

  case "$LAO_OS_ID" in
    arch|cachyos|manjaro|endeavouros) LAO_DISTRO_FAMILY="arch" ;;
    debian|ubuntu|linuxmint|pop|zorin|neon|kali|elementary|tuxedo) LAO_DISTRO_FAMILY="debian" ;;
    fedora|nobara|ultramarine|rhel|centos|rocky|almalinux) LAO_DISTRO_FAMILY="fedora" ;;
    *)
      if os_like_has arch; then LAO_DISTRO_FAMILY="arch"
      elif os_like_has debian || os_like_has ubuntu; then LAO_DISTRO_FAMILY="debian"
      elif os_like_has fedora || os_like_has rhel || os_like_has centos; then LAO_DISTRO_FAMILY="fedora"
      fi
      ;;
  esac

  # Tool availability is checked independently from the marketing distribution
  # name. No package-manager command is executed by detection.
  case "$LAO_DISTRO_FAMILY" in
    arch) have pacman && LAO_PKG_MANAGER="pacman" || LAO_PKG_MANAGER="unavailable" ;;
    debian) have apt-get && LAO_PKG_MANAGER="apt-get" || LAO_PKG_MANAGER="unavailable" ;;
    fedora)
      if have dnf5; then LAO_PKG_MANAGER="dnf5"
      elif have dnf; then LAO_PKG_MANAGER="dnf"
      else LAO_PKG_MANAGER="unavailable"; fi
      ;;
    *)
      local found=() manager
      for manager in pacman apt-get dnf5 dnf; do have "$manager" && found+=("$manager"); done
      if ((${#found[@]} == 1)); then LAO_PKG_MANAGER="unverified:${found[0]}"; fi
      ;;
  esac
}

load_cpu_info() {
  local parsed
  if have lscpu; then
    parsed="$(lscpu 2>/dev/null || true)"
    LAO_CPU_MODEL="$(awk -F: '/^(Model name|Model):/ {sub(/^[ \t]+/, "", $2); print $2; exit}' <<< "$parsed")"
    LAO_CPU_VENDOR="$(awk -F: '/^Vendor ID:/ {sub(/^[ \t]+/, "", $2); print $2; exit}' <<< "$parsed")"
  fi
  if [[ -z "$LAO_CPU_MODEL" || "$LAO_CPU_MODEL" == unknown ]]; then
    LAO_CPU_MODEL="$(awk -F: '/^(model name|Hardware)[ \t]*:/ {sub(/^[ \t]+/, "", $2); print $2; exit}' /proc/cpuinfo 2>/dev/null || true)"
  fi
  if [[ -z "$LAO_CPU_VENDOR" || "$LAO_CPU_VENDOR" == unknown ]]; then
    LAO_CPU_VENDOR="$(awk -F: '/vendor_id[ \t]*:/ {sub(/^[ \t]+/, "", $2); print $2; exit}' /proc/cpuinfo 2>/dev/null || true)"
  fi
  LAO_CPU_MODEL="${LAO_CPU_MODEL:-unknown}"
  LAO_CPU_VENDOR="${LAO_CPU_VENDOR:-unknown}"
  LAO_CPU_THREADS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || printf 1)"
}

load_memory_info() {
  if [[ -r /proc/meminfo ]]; then
    LAO_RAM_KB="$(awk '/^MemTotal:/ {print $2; exit}' /proc/meminfo)"
    LAO_RAM_AVAILABLE_KB="$(awk '/^MemAvailable:/ {print $2; exit}' /proc/meminfo)"
    LAO_SWAP_KB="$(awk '/^SwapTotal:/ {print $2; exit}' /proc/meminfo)"
  fi
  LAO_RAM_KB="${LAO_RAM_KB:-0}"
  LAO_RAM_AVAILABLE_KB="${LAO_RAM_AVAILABLE_KB:-0}"
  LAO_SWAP_KB="${LAO_SWAP_KB:-0}"
}

load_virtualization() {
  local detected=""
  if have systemd-detect-virt; then
    detected="$(systemd-detect-virt 2>/dev/null || true)"
  fi
  if [[ -n "$detected" ]]; then
    LAO_VIRT="$detected"
  elif grep -qiE 'hypervisor|QEMU|VMware|VirtualBox|KVM' /proc/cpuinfo /sys/class/dmi/id/sys_vendor 2>/dev/null; then
    LAO_VIRT="virtualization-detected"
  else
    LAO_VIRT="none-or-unavailable"
  fi
}

load_gpu_info() {
  local gpu="" card vendor device driver
  if have lspci; then
    gpu="$(lspci -nn 2>/dev/null | grep -Ei 'VGA compatible controller|3D controller|Display controller' | sed 's/^[^ ]* //' || true)"
  fi
  if [[ -z "$gpu" && -d /sys/class/drm ]]; then
    for card in /sys/class/drm/card[0-9]*; do
      [[ -e "$card/device" ]] || continue
      vendor="$(cat "$card/device/vendor" 2>/dev/null || true)"
      device="$(cat "$card/device/device" 2>/dev/null || true)"
      driver="$(basename "$(readlink -f "$card/device/driver" 2>/dev/null)" 2>/dev/null || true)"
      gpu+="${card##*/} vendor=${vendor:-?} device=${device:-?} driver=${driver:-?}; "
    done
  fi
  LAO_GPU_SUMMARY="${gpu:-não identificada}"
}

load_kernel_metadata() {
  if [[ -d /run/systemd/system ]]; then LAO_INIT="systemd"
  elif [[ -x /sbin/openrc ]]; then LAO_INIT="openrc"
  else LAO_INIT="não identificado"; fi
  case "$(uname -r)" in
    *cachyos*) LAO_KERNEL_FLAVOR="CachyOS-like" ;;
    *zen*) LAO_KERNEL_FLAVOR="Zen-like" ;;
    *liquorix*) LAO_KERNEL_FLAVOR="Liquorix-like" ;;
    *xanmod*) LAO_KERNEL_FLAVOR="XanMod-like" ;;
    *generic*) LAO_KERNEL_FLAVOR="generic-like" ;;
    *) LAO_KERNEL_FLAVOR="custom-or-distribution" ;;
  esac
  local dir version
  for dir in /usr/lib/modules/* /lib/modules/*; do
    [[ -d "$dir" ]] || continue
    version="${dir##*/}"
    [[ " $LAO_KERNEL_INSTALLED " == *" $version "* ]] || LAO_KERNEL_INSTALLED+="${version} "
  done
  LAO_KERNEL_INSTALLED="${LAO_KERNEL_INSTALLED% }"
}

initialize_detection() {
  load_os_release
  load_cpu_info
  load_memory_info
  load_virtualization
  load_gpu_info
  load_kernel_metadata
}

format_kib() {
  local value="${1:-0}"
  if [[ "$value" =~ ^[0-9]+$ ]] && (( value > 0 )); then
    awk -v kb="$value" 'BEGIN {printf "%.2f GiB", kb/1048576}'
  else printf 'indisponível'; fi
}

print_system_summary() {
  module_header "VISÃO GERAL DO SISTEMA | LAO ${LAO_VERSION}"
  status_line "Distribuição" "$LAO_OS_NAME"
  status_line "ID / versão" "$LAO_OS_ID / $LAO_OS_VERSION"
  status_line "ID_LIKE" "${LAO_OS_LIKE:-não informado}"
  status_line "Família detectada" "$LAO_DISTRO_FAMILY"
  status_line "Gerenciador detectado" "$LAO_PKG_MANAGER"
  status_line "Arquitetura" "$LAO_CPU_ARCH"
  status_line "CPU" "$LAO_CPU_MODEL"
  status_line "Vendor CPU" "$LAO_CPU_VENDOR"
  status_line "Threads online" "$LAO_CPU_THREADS"
  status_line "RAM total" "$(format_kib "$LAO_RAM_KB")"
  status_line "RAM disponível" "$(format_kib "$LAO_RAM_AVAILABLE_KB")"
  status_line "Swap total" "$(format_kib "$LAO_SWAP_KB")"
  status_line "GPU" "$LAO_GPU_SUMMARY"
  status_line "Ambiente gráfico" "$LAO_DE"
  status_line "Display server" "$LAO_DISPLAY"
  status_line "Virtualização" "$LAO_VIRT"
  status_line "Kernel em execução" "$(uname -r) ($LAO_KERNEL_FLAVOR)"
  status_line "Kernels instalados" "${LAO_KERNEL_INSTALLED:-não identificados}"
  status_line "Init" "$LAO_INIT"
}

cpu_capability_report() {
  local policy file
  if [[ -d /sys/devices/system/cpu/cpufreq ]]; then
    for policy in /sys/devices/system/cpu/cpufreq/policy[0-9]*; do
      [[ -d "$policy" ]] || continue
      printf '  Política: %s\n' "${policy##*/}"
      for file in affected_cpus related_cpus scaling_driver scaling_governor scaling_available_governors scaling_min_freq scaling_max_freq scaling_cur_freq cpuinfo_min_freq cpuinfo_max_freq energy_performance_preference energy_performance_available_preferences; do
        [[ -r "$policy/$file" ]] && printf '    %-43s %s\n' "$file" "$(cat "$policy/$file" 2>/dev/null)"
      done
    done
  else
    printf '  CPUFreq sysfs: indisponível\n'
  fi
  [[ -r /sys/devices/system/cpu/online ]] && printf '  CPUs online: %s\n' "$(cat /sys/devices/system/cpu/online)"
  [[ -r /sys/devices/system/cpu/smt/active ]] && printf '  SMT ativo: %s\n' "$(cat /sys/devices/system/cpu/smt/active)"
  [[ -r /sys/devices/system/cpu/smt/control ]] && printf '  SMT control: %s\n' "$(cat /sys/devices/system/cpu/smt/control)"
  local vuln
  for vuln in /sys/devices/system/cpu/vulnerabilities/*; do
    [[ -r "$vuln" ]] && printf '  Mitigação %-30s %s\n' "${vuln##*/}" "$(cat "$vuln" 2>/dev/null)"
  done
}

storage_capability_report() {
  if have lsblk; then
    lsblk -e 7 -o NAME,TYPE,SIZE,ROTA,TRAN,FSTYPE,MOUNTPOINTS,MODEL 2>/dev/null || true
  else
    printf '  lsblk indisponível; dispositivos em /sys/block: '
    printf '%s ' /sys/block/*
    printf '\n'
  fi
  local block sched rotational discard
  for block in /sys/block/*; do
    [[ -d "$block/queue" ]] || continue
    sched="$block/queue/scheduler"
    rotational="$(cat "$block/queue/rotational" 2>/dev/null || printf '?')"
    discard="$(cat "$block/queue/discard_max_bytes" 2>/dev/null || printf '?')"
    printf '  %-18s rotational=%s discard_max_bytes=%s' "${block##*/}" "$rotational" "$discard"
    [[ -r "$sched" ]] && printf ' scheduler=%s' "$(cat "$sched" 2>/dev/null)"
    [[ -r "$block/queue/read_ahead_kb" ]] && printf ' read_ahead_kb=%s' "$(cat "$block/queue/read_ahead_kb" 2>/dev/null)"
    printf '\n'
  done
}

print_detailed_diagnostics() {
  local file
  module_header "CPU, TOPOLOGIA E FREQUÊNCIA"
  if have lscpu; then
    lscpu 2>/dev/null | grep -E '^(Architecture|CPU op-mode|Vendor ID|CPU family|Model:|Model name|Stepping|CPU\(s\)|On-line CPU|Thread\(s\) per core|Core\(s\) per socket|Socket\(s\)|NUMA node\(s\)|NUMA node[0-9]+ CPU\(s\)|L1d cache|L1i cache|L2 cache|L3 cache|Virtualization|Hypervisor vendor|Flags):' | head -n 45 || true
    printf '\nTopologia por CPU (amostra):\n'
    lscpu -e=CPU,CORE,SOCKET,NODE 2>/dev/null | head -n 20 || true
  fi
  cpu_capability_report

  module_header "MEMÓRIA, SWAP, ZRAM E PRESSÃO"
  if have free; then free -h; else head -n 18 /proc/meminfo 2>/dev/null || true; fi
  if have swapon; then swapon --show --bytes 2>/dev/null || true; fi
  if have zramctl; then zramctl 2>/dev/null || true; fi
  if have dmidecode && [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
    dmidecode --type memory 2>/dev/null | grep -E '^[[:space:]]*(Size:|Type:|Speed:|Configured Memory Speed:|Locator:)' | head -n 36 || true
  else
    log INFO "Tipo/velocidade física da RAM exigem dmidecode e, em geral, acesso ao firmware; não inferidos pela frequência da CPU."
  fi
  for file in /proc/pressure/cpu /proc/pressure/memory /proc/pressure/io; do
    [[ -r "$file" ]] && { printf '\n%s\n' "$file"; cat "$file"; }
  done
  for file in /sys/kernel/mm/transparent_hugepage/enabled /sys/kernel/mm/transparent_hugepage/defrag /sys/kernel/mm/transparent_hugepage/shmem_enabled; do
    [[ -r "$file" ]] && printf '%s: %s\n' "$file" "$(cat "$file" 2>/dev/null)"
  done
  for file in /proc/sys/vm/swappiness /proc/sys/vm/vfs_cache_pressure /proc/sys/vm/dirty_ratio /proc/sys/vm/dirty_background_ratio /proc/sys/vm/overcommit_memory; do
    [[ -r "$file" ]] && printf '%s: %s\n' "$file" "$(cat "$file" 2>/dev/null)"
  done
  if [[ -d /sys/devices/system/node ]]; then printf 'NUMA nodes: '; printf '%s ' /sys/devices/system/node/node[0-9]*; printf '\n'; fi

  module_header "ARMAZENAMENTO E FILESYSTEMS"
  storage_capability_report
  if have findmnt; then findmnt -rn -o SOURCE,TARGET,FSTYPE,OPTIONS 2>/dev/null | head -n 36 || true; fi
  if have smartctl; then smartctl --scan 2>/dev/null | head -n 20 || true; fi
  if have nvme; then nvme list 2>/dev/null | head -n 20 || true; fi
  if have sensors; then sensors 2>/dev/null | head -n 35 || true; fi
  if have systemctl && [[ -d /run/systemd/system ]]; then
    printf 'fstrim.timer: enabled=%s active=%s\n' "$(systemctl is-enabled fstrim.timer 2>/dev/null || printf unknown)" "$(systemctl is-active fstrim.timer 2>/dev/null || printf unknown)"
  fi

  module_header "GPU E STACK GRÁFICA"
  printf '  %s\n' "$LAO_GPU_SUMMARY"
  if have lspci; then lspci -nnk 2>/dev/null | grep -A3 -Ei 'VGA compatible controller|3D controller|Display controller' || true; fi
  if have glxinfo; then glxinfo -B 2>/dev/null | sed -n '1,14p' || true; fi
  if have vulkaninfo; then vulkaninfo --summary 2>/dev/null | sed -n '1,20p' || true; fi
  if have vainfo; then vainfo 2>&1 | sed -n '1,20p' || true; fi
  if have nvidia-smi; then nvidia-smi --query-gpu=name,driver_version,pstate,temperature.gpu --format=csv,noheader 2>/dev/null || true; fi
  if [[ -d /sys/class/drm ]]; then
    local card driver
    for card in /sys/class/drm/card[0-9]*; do
      [[ -e "$card/device" ]] || continue
      driver="$(basename "$(readlink -f "$card/device/driver" 2>/dev/null)" 2>/dev/null || true)"
      printf '  %-12s vendor=%s device=%s driver=%s\n' "${card##*/}" "$(cat "$card/device/vendor" 2>/dev/null || printf '?')" "$(cat "$card/device/device" 2>/dev/null || printf '?')" "${driver:-indisponível}"
    done
  fi

  module_header "REDE"
  if have ip; then ip -brief link 2>/dev/null || true; ip -brief address 2>/dev/null || true; fi
  if have iw; then iw dev 2>/dev/null | head -n 28 || true; fi
  for file in /proc/sys/net/ipv4/tcp_congestion_control /proc/sys/net/ipv4/tcp_available_congestion_control /proc/sys/net/core/rmem_max /proc/sys/net/core/wmem_max; do
    [[ -r "$file" ]] && printf '  %-45s %s\n' "$file" "$(cat "$file" 2>/dev/null)"
  done
  if have tc; then tc qdisc show 2>/dev/null | head -n 25 || true; fi

  module_header "SERVIÇOS E BOOT"
  if have systemd-analyze && [[ -d /run/systemd/system ]]; then
    systemd-analyze time 2>/dev/null || true
    systemd-analyze blame 2>/dev/null | head -n 18 || true
    systemctl --failed --no-pager 2>/dev/null | head -n 20 || true
  else
    log INFO "systemd não está ativo ou suas ferramentas não estão disponíveis."
  fi
  status_line "Firmware boot" "$( [[ -d /sys/firmware/efi ]] && printf UEFI || printf 'BIOS/Legacy ou EFI não exposto' )"
  status_line "Kernel cmdline" "$(cat /proc/cmdline 2>/dev/null)"

  module_header "PLACA-MÃE, FIRMWARE, PCI E USB"
  for file in sys_vendor product_name board_name board_vendor board_version bios_vendor bios_version bios_date; do
    [[ -r "/sys/class/dmi/id/$file" ]] && printf '  %-20s %s\n' "$file" "$(cat "/sys/class/dmi/id/$file" 2>/dev/null)"
  done
  if have lspci; then lspci -nnk 2>/dev/null | head -n 65 || true; fi
  if have lsusb; then lsusb 2>/dev/null | head -n 28 || true; fi
  if have lsmod; then lsmod 2>/dev/null | head -n 35 || true; elif [[ -r /proc/modules ]]; then head -n 35 /proc/modules; fi
  if [[ -r /proc/config.gz ]]; then status_line "Kernel config" "/proc/config.gz"
  elif [[ -r "/boot/config-$(uname -r)" ]]; then status_line "Kernel config" "/boot/config-$(uname -r)"
  elif [[ -r "/lib/modules/$(uname -r)/build/.config" ]]; then status_line "Kernel config" "/lib/modules/$(uname -r)/build/.config"
  else status_line "Kernel config" "indisponível"; fi

  module_header "SEGURANÇA E MITIGAÇÕES"
  if have mokutil; then mokutil --sb-state 2>/dev/null || true
  elif [[ -d /sys/firmware/efi/efivars ]]; then log INFO "Secure Boot: efivars presente; estado exato não verificado sem mokutil."; fi
  if have firewall-cmd; then firewall-cmd --state 2>/dev/null || true; fi
  if have ufw; then ufw status 2>/dev/null | head -n 5 || true; fi
  if have systemctl && [[ -d /run/systemd/system ]]; then
    printf 'firewalld=%s ufw=%s\n' "$(systemctl is-active firewalld 2>/dev/null || printf unknown)" "$(systemctl is-active ufw 2>/dev/null || printf unknown)"
  fi
}
