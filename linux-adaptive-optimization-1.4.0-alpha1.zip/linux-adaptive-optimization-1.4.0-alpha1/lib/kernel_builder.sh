#!/usr/bin/env bash
# Local-only kernel configuration and compilation helper.
# Never installs packages, writes /boot, installs modules, or edits boot entries.

kernel_arch() {
  case "$(uname -m)" in
    x86_64|i?86) printf 'x86' ;;
    aarch64) printf 'arm64' ;;
    armv*) printf 'arm' ;;
    ppc64|ppc64le) printf 'powerpc' ;;
    riscv64) printf 'riscv' ;;
    s390x) printf 's390' ;;
    *) uname -m ;;
  esac
}

kernel_builder_workspace() {
  local base="${XDG_CACHE_HOME:-${HOME:-/tmp}/.cache}"
  printf '%s/lao/kernel-builder' "$base"
}

cgroup_memory_limit_kb() {
  local value=""
  if [[ -r /sys/fs/cgroup/memory.max ]]; then
    value="$(cat /sys/fs/cgroup/memory.max 2>/dev/null)"
    if [[ "$value" =~ ^[0-9]+$ ]] && (( value > 0 && value < 9000000000000000000 )); then
      printf '%s' "$((value / 1024))"; return 0
    fi
  fi
  if [[ -r /sys/fs/cgroup/memory/memory.limit_in_bytes ]]; then
    value="$(cat /sys/fs/cgroup/memory/memory.limit_in_bytes 2>/dev/null)"
    if [[ "$value" =~ ^[0-9]+$ ]] && (( value > 0 && value < 9000000000000000000 )); then
      printf '%s' "$((value / 1024))"; return 0
    fi
  fi
  return 1
}

cgroup_cpu_limit() {
  local quota period count
  if [[ -r /sys/fs/cgroup/cpu.max ]]; then
    read -r quota period < /sys/fs/cgroup/cpu.max || true
    if [[ "${quota:-}" =~ ^[0-9]+$ && "${period:-}" =~ ^[0-9]+$ ]] && (( period > 0 )); then
      count=$(( (quota + period - 1) / period )); (( count < 1 )) && count=1
      printf '%s' "$count"; return 0
    fi
  fi
  if [[ -r /sys/fs/cgroup/cpu/cpu.cfs_quota_us && -r /sys/fs/cgroup/cpu/cpu.cfs_period_us ]]; then
    quota="$(cat /sys/fs/cgroup/cpu/cpu.cfs_quota_us 2>/dev/null)"
    period="$(cat /sys/fs/cgroup/cpu/cpu.cfs_period_us 2>/dev/null)"
    if [[ "$quota" =~ ^[0-9]+$ && "$period" =~ ^[0-9]+$ ]] && (( quota > 0 && period > 0 )); then
      count=$(( (quota + period - 1) / period )); (( count < 1 )) && count=1
      printf '%s' "$count"; return 0
    fi
  fi
  return 1
}

recommended_kernel_jobs() {
  local cpus mem_kb cgroup_kb cgroup_cpus jobs
  cpus="$(getconf _NPROCESSORS_ONLN 2>/dev/null || printf 1)"
  mem_kb="$(awk '/^MemAvailable:/ {print $2; exit}' /proc/meminfo 2>/dev/null)"
  [[ "$cpus" =~ ^[1-9][0-9]*$ ]] || cpus=1
  [[ "$mem_kb" =~ ^[0-9]+$ ]] || mem_kb=2097152
  if cgroup_kb="$(cgroup_memory_limit_kb 2>/dev/null)"; then
    (( cgroup_kb < mem_kb )) && mem_kb="$cgroup_kb"
  fi
  if cgroup_cpus="$(cgroup_cpu_limit 2>/dev/null)"; then
    (( cgroup_cpus < cpus )) && cpus="$cgroup_cpus"
  fi
  # Conservative ceiling: one concurrent compile job per ~2 GiB available
  # within the current cgroup, capped by online/cgroup CPU quota.
  jobs=$((mem_kb / 2097152))
  (( jobs < 1 )) && jobs=1
  (( jobs > cpus )) && jobs="$cpus"
  printf '%s' "$jobs"
}

find_running_kernel_config() {
  if [[ -r /proc/config.gz ]] && have zcat; then
    zcat /proc/config.gz 2>/dev/null
  elif [[ -r "/boot/config-$(uname -r)" ]]; then
    cat "/boot/config-$(uname -r)"
  elif [[ -r "/lib/modules/$(uname -r)/build/.config" ]]; then
    cat "/lib/modules/$(uname -r)/build/.config"
  else
    return 1
  fi
}

kernel_source_identity() {
  local source="$1" version="unknown" revision="unversioned"
  local file_hash mode_hash link_hash dir_hash tree_hash
  have sha256sum || { log ERROR "sha256sum é necessário para identificar a árvore de kernel com segurança."; return 1; }
  if have make; then version="$(make -s -C "$source" kernelversion 2>/dev/null || printf unknown)"; fi
  if have git && git -C "$source" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    revision="$(git -C "$source" rev-parse --short HEAD 2>/dev/null || printf unknown)"
  fi

  # Fingerprint all files outside .git, including tarball sources without Git.
  # File content, file modes, directory modes and symlink targets are included.
  # Kbuild output stays outside this source tree via O=, so a changed tree is
  # evidence that the reviewed input differs from the input about to be built.
  file_hash="$(cd -- "$source" && find . -path './.git' -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 -r sha256sum -- | sha256sum | awk '{print $1}')" || return 1
  mode_hash="$(cd -- "$source" && find . -path './.git' -prune -o -type f -printf '%m %p\n' | LC_ALL=C sort | sha256sum | awk '{print $1}')" || return 1
  dir_hash="$(cd -- "$source" && find . -path './.git' -prune -o -type d -printf '%m %p\n' | LC_ALL=C sort | sha256sum | awk '{print $1}')" || return 1
  link_hash="$(cd -- "$source" && find . -path './.git' -prune -o -type l -printf '%p -> %l\n' | LC_ALL=C sort | sha256sum | awk '{print $1}')" || return 1
  tree_hash="$(printf '%s:%s:%s:%s' "$file_hash" "$mode_hash" "$dir_hash" "$link_hash" | sha256sum | awk '{print $1}')" || return 1
  printf 'version=%s revision=%s tree_sha256=%s' "$version" "$revision" "$tree_hash"
}

kernel_builder_prepare() {
  local source="$1" workspace build_dir config_file arch identity
  if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
    log ERROR "Não execute a preparação de kernel como root. Kbuild executa código da árvore de fontes; use uma conta normal."
    return 2
  fi
  [[ -n "$source" && -d "$source" && -r "$source/Makefile" && -r "$source/Kconfig" ]] || {
    log ERROR "Informe uma árvore de código-fonte Linux local válida via --kernel-source DIR. Downloads automáticos são proibidos."
    return 2
  }
  source="$(cd -- "$source" && pwd -P)"
  have make || { log ERROR "make não está instalado."; return 2; }
  workspace="$(kernel_builder_workspace)"
  [[ ! -L "$workspace" ]] || { log ERROR "Workspace do kernel é link simbólico; operação recusada."; return 1; }
  mkdir -p -- "$workspace" || return 1
  [[ -O "$workspace" ]] || { log ERROR "Workspace do kernel não pertence ao usuário atual."; return 1; }
  chmod 700 "$workspace" 2>/dev/null || true
  arch="$(kernel_arch)"
  build_dir="$(mktemp -d "$workspace/build-$(date +%Y%m%d-%H%M%S)-XXXXXX")" || return 1
  chmod 700 "$build_dir"
  config_file="$build_dir/.config"

  if [[ -r "$source/.config" ]]; then
    cp -p -- "$source/.config" "$config_file"
    log INFO "Configuração-base copiada da árvore local; a origem não será editada."
  elif find_running_kernel_config > "$config_file" 2>/dev/null; then
    log INFO "Configuração-base obtida do kernel em execução."
  else
    rm -rf -- "$build_dir"
    log ERROR "Não foi possível localizar uma configuração-base (.config, /proc/config.gz ou /boot/config-*)."
    return 2
  fi
  cp -p -- "$config_file" "$build_dir/.config.baseline"
  identity="$(kernel_source_identity "$source")" || { rm -rf -- "$build_dir"; log ERROR "Não foi possível calcular a identidade criptográfica da árvore de fontes."; return 1; }

  cat > "$build_dir/BUILD-PLAN.txt" <<PLAN
Linux Adaptive Optimization Engine - Kernel Build Plan
Created UTC: $(date -u +%FT%TZ)
Source: $source
Source identity: $identity
Build output: $build_dir
Host architecture: $arch
Running kernel: $(uname -r)
CPU model: ${LAO_CPU_MODEL:-unknown}

Safety boundaries:
- This plan uses a local source tree only; it does not download source.
- The source tree is not edited; output is placed in a separate O= directory.
- Baseline configuration is preserved as .config.baseline.
- olddefconfig may add/remove symbols according to this source tree's Kconfig.
- No localmodconfig is run because disconnected/future devices could be removed.
- No modules_install, install, initramfs generation, bootloader update or reboot is performed.
- Inspect .config.diff and the configuration before compiling.
- Only build source obtained from a trusted upstream and independently verified.
PLAN
  printf '%s\n' "$source" > "$build_dir/SOURCE_PATH"
  printf '%s\n' "$identity" > "$build_dir/SOURCE_IDENTITY"

  log STEP "Preparando configuração fora da árvore de fontes"
  if ! make -C "$source" O="$build_dir" ARCH="$arch" olddefconfig; then
    log ERROR "olddefconfig falhou. Diretório preservado para inspeção: $build_dir"
    return 1
  fi
  [[ -s "$config_file" && ! -L "$config_file" ]] || { log ERROR "olddefconfig não produziu .config válido."; return 1; }
  diff -u "$build_dir/.config.baseline" "$config_file" > "$build_dir/.config.diff" || true
  log OK "Configuração preparada: $config_file"
  log INFO "Identidade da fonte: $identity"
  log INFO "Plano: $build_dir/BUILD-PLAN.txt"
  log WARN "Sem instalação de kernel, módulos, initramfs ou entrada de boot."
}

kernel_builder_compile() {
  local source="$1" jobs="$2" workspace build_dir free_kb required_kb candidate
  if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
    log ERROR "Não execute a compilação de kernel como root. Use uma conta normal."
    return 2
  fi
  [[ -n "$source" && -d "$source" && -r "$source/Makefile" ]] || {
    log ERROR "Forneça uma árvore de código-fonte local válida com --kernel-source DIR."
    return 2
  }
  source="$(cd -- "$source" && pwd -P)"
  [[ "${LAO_CONFIRM_KERNEL_BUILD:-0}" == 1 ]] || {
    log ERROR "Compilação exige --confirm-kernel-build."
    return 2
  }
  have make || { log ERROR "make não está instalado."; return 2; }
  local -a compiler_args=()
  if have gcc; then
    :
  elif have clang; then
    have ld.lld || log WARN "ld.lld não encontrado; compilação LLVM pode falhar conforme a configuração."
    compiler_args=(LLVM=1)
  else
    log ERROR "Nenhum compilador GCC/Clang encontrado."; return 2
  fi
  local missing=() tool
  for tool in bc flex bison perl python3; do have "$tool" || missing+=("$tool"); done
  if ((${#missing[@]})); then
    log ERROR "Dependências básicas ausentes: ${missing[*]}. LAO não instalará pacotes automaticamente."
    return 2
  fi
  [[ "$jobs" =~ ^[1-9][0-9]*$ ]] && (( jobs <= 256 )) || { log ERROR "Número de jobs inválido: $jobs (intervalo permitido: 1-256)."; return 2; }
  workspace="$(kernel_builder_workspace)"
  [[ -d "$workspace" && ! -L "$workspace" && -O "$workspace" ]] || { log ERROR "Workspace de kernel não existe, não pertence ao usuário ou é link simbólico."; return 2; }
  chmod 700 "$workspace" 2>/dev/null || { log ERROR "Não foi possível restringir as permissões do workspace."; return 1; }
  build_dir=""
  for candidate in "$workspace"/build-*; do
    [[ -d "$candidate" && ! -L "$candidate" && -O "$candidate" && -r "$candidate/.config" && -r "$candidate/SOURCE_PATH" && ! -L "$candidate/SOURCE_PATH" && ! -L "$candidate/SOURCE_IDENTITY" ]] || continue
    if [[ "$(cat "$candidate/SOURCE_PATH" 2>/dev/null)" == "$source" ]]; then build_dir="$candidate"; fi
  done
  [[ -n "$build_dir" && -r "$build_dir/.config" ]] || {
    log ERROR "Nenhuma preparação válida para esta árvore de fontes. Execute primeiro --kernel-builder --kernel-source DIR."
    return 2
  }
  local current_identity
  current_identity="$(kernel_source_identity "$source")" || { log ERROR "Não foi possível verificar a identidade atual da fonte."; return 1; }
  [[ "$(cat "$build_dir/SOURCE_IDENTITY" 2>/dev/null)" == "$current_identity" ]] || {
    log ERROR "A identidade/revisão da árvore de fontes mudou após a preparação. Prepare novamente e revise a configuração."; return 2;
  }
  free_kb="$(df -Pk "$build_dir" | awk 'NR==2 {print $4}')"
  required_kb=$((15 * 1024 * 1024))
  if [[ ! "$free_kb" =~ ^[0-9]+$ ]] || (( free_kb < required_kb )); then
    log ERROR "Espaço livre insuficiente: ${free_kb:-desconhecido} KiB; a política conservadora exige 15 GiB livres."
    return 2
  fi
  if grep -q '^CONFIG_DEBUG_INFO_BTF=y' "$build_dir/.config" && ! have pahole; then
    log WARN "CONFIG_DEBUG_INFO_BTF=y, mas pahole não está instalado; a compilação pode falhar."
  fi
  if ! have openssl; then log WARN "openssl não encontrado; algumas configurações de assinatura/compilação podem exigir a ferramenta."; fi
  local log_file="$build_dir/compile.log"
  log STEP "Compilando fonte local: jobs=$jobs; $(kernel_source_identity "$source")"
  log WARN "A compilação pode saturar CPU, memória e armazenamento. Nenhum artefato será instalado."
  if make -C "$source" O="$build_dir" ARCH="$(kernel_arch)" "${compiler_args[@]}" -j "$jobs" 2>&1 | tee "$log_file"; then
    log OK "Compilação concluída. Log: $log_file"
    log INFO "Artefatos permanecem em $build_dir. Instalação e integração de boot não são executadas."
  else
    log ERROR "Compilação falhou. Consulte $log_file; o sistema em execução não foi modificado."
    return 1
  fi
}
