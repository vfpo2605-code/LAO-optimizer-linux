# Technical references

Research snapshot: 2026-11-23. Prefer current upstream documentation and verify the running kernel's sysfs values before writing.

1. **CPUFreq policy interface and governor semantics**  
   https://docs.kernel.org/admin-guide/pm/cpufreq.html  
   The kernel exposes per-policy governor values and available-governor lists. A governor name is not assumed to have identical driver semantics on every platform.

2. **Intel P-State / EPP**  
   https://docs.kernel.org/admin-guide/pm/intel_pstate.html  
   `energy_performance_preference` and `energy_performance_available_preferences` are conditional policy attributes. Some driver modes can constrain or override EPP values; the engine reads back after writing.

3. **AMD P-State / EPP**  
   https://docs.kernel.org/admin-guide/pm/amd-pstate.html  
   EPP is a firmware-facing performance/energy hint. The exact impact can differ by platform; the driver-provided preference list is the source of acceptable named choices.

4. **VM sysctl documentation**  
   https://docs.kernel.org/admin-guide/sysctl/vm.html  
   Swappiness expresses relative I/O cost between swapping and filesystem paging, not a universal “less is faster” slider. The documentation describes a 0-200 range and notes workload dependence, including in-memory swap cases.

5. **Block I/O scheduler switching**  
   https://docs.kernel.org/block/switching-sched.html  
   The scheduler interface is per block queue. Reading `/sys/block/DEV/queue/scheduler` lists available names and brackets the active choice; writing a valid name switches that device. Availability is not evidence that a scheduler improves a workload, so LAO only switches when the user explicitly supplies both device and scheduler.

6. **Block queue sysfs attributes**  
   https://docs.kernel.org/block/queue-sysfs.html

7. **ZRAM administration**  
   https://docs.kernel.org/admin-guide/blockdev/zram.html  
   ZRAM has lifecycle and device configuration steps. It is not safe to initialize/replace a user's current swap device without inspecting active devices and coordinating swap state; LAO only reports it.

8. **IP sysctl**  
   https://docs.kernel.org/networking/ip-sysctl.html  
   `tcp_available_congestion_control` reports registered algorithms and `tcp_congestion_control` selects the default for new TCP connections. LAO requires the explicit requested name to appear in the runtime list. It does not assume that `bbr`, `cubic` or another algorithm is faster for every network path.

9. **systemd `systemctl`**  
   https://www.freedesktop.org/software/systemd/man/latest/systemctl.html  
   Service state and unit operations are separate concepts. LAO currently inventories units and does not disable, mask, stop or restart them.

10. **Linux kernel build documentation**  
    https://docs.kernel.org/kbuild/kbuild.html  
    The builder uses the `O=` output-tree mechanism to keep generated output separate from the source tree.

The project avoids copying tuning values from forum posts or benchmark screenshots as universal defaults. `vm.swappiness` is described by the kernel as a relative I/O-cost setting in the 0–200 range whose optimal value is workload-dependent; LAO therefore exposes only an explicit one-shot choice and leaves profile defaults unset. The same rule applies to per-device scheduler selection and TCP congestion control. A tunable remaining read-only is an intentional engineering decision when no safe workload-independent choice is established.
