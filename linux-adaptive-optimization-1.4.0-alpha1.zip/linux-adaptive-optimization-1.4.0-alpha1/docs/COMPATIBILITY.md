# Compatibility matrix for LAO 1.4.0-alpha1

LAO targets Linux and Bash 4.4+. Distro detection uses `/etc/os-release` (`ID`, `ID_LIKE`, `VERSION_ID`) and checks whether the corresponding package manager exists. The current program does not install packages or invoke a package manager. A recognized family is not proof that every derivative uses identical repositories, kernel policies or boot tooling.

## Distribution families

| Family | Detection signals | Package manager identified | Status |
|---|---|---|---|
| Arch | `ID=arch` or `ID_LIKE` token `arch`; known IDs CachyOS, Manjaro, EndeavourOS | `pacman` if present | Detection implemented; separate derivative runs not performed |
| Debian/Ubuntu | Debian/Ubuntu-like tokens and known IDs | `apt-get` if present | Detection implemented; separate derivative runs not performed |
| Fedora/RHEL | Fedora/RHEL-like tokens and known IDs | `dnf5` preferred, else `dnf` | Detection implemented; separate derivative runs not performed |
| Unknown | Other IDs/ID_LIKE values | A single available pacman/apt-get/dnf can be tagged unverified | No tuning policy inferred |

Package-manager support is identification-only in 1.4.0-alpha1. There is no dependency installation abstraction yet because the program intentionally installs nothing.

## Feature compatibility

| Feature | Status | Conditions / limits |
|---|---|---|
| Hardware and OS inventory | Implemented, best-effort | Depends on procfs/sysfs and optional tools; values may be unavailable in containers |
| CPUFreq governor | Conditional runtime write | Policy exists; desired governor is listed by that policy; no recognized competing power manager |
| CPU EPP | Conditional runtime write | Available and writable EPP attributes; requested EPP value is listed by driver |
| `vm.swappiness` | Explicit runtime write | Value 0–200; `/proc/sys/vm/swappiness` writable; no auto-selected value |
| `vm.vfs_cache_pressure` | Explicit runtime write | Value 0–1000; no auto-selected value |
| `vm.dirty_ratio` / `vm.dirty_background_ratio` | Explicit runtime write | Values 0–100; final background ratio must not exceed dirty ratio |
| Block I/O scheduler | Explicit runtime write | Exact device queue and scheduler name exist; per-device operation |
| TCP congestion control | Explicit runtime write | Exact algorithm is registered in `tcp_available_congestion_control`; affects new TCP connections |
| GPU performance controls | Read-only diagnostics | PCI/DRM/vendor tools; no driver/clock/power changes |
| Services and desktop | Read-only diagnostics | systemd and session variables where available; no service or user preference changes |
| Boot and security | Read-only diagnostics | Kernel cmdline, boot timing, mitigations, firewall/Secure Boot information where exposed |
| Kernel builder | Local prepare/build only | Requires trusted local sources, toolchain, workspace; runs unprivileged; no package/install/initramfs/bootloader integration |
| CPU benchmark | Conditional | `sysbench` must already exist; only CPU test; no benchmark gain assumed |

## Supported kernel/user-space interfaces

The program checks for these runtime interfaces instead of assuming that a CPU/GPU vendor label means the feature exists:

- `/sys/devices/system/cpu/cpufreq/policy*/scaling_available_governors`
- `/sys/devices/system/cpu/cpufreq/policy*/energy_performance_available_preferences`
- `/sys/block/DEV/queue/scheduler`
- `/proc/sys/vm/swappiness`, `/proc/sys/vm/vfs_cache_pressure`, `/proc/sys/vm/dirty_ratio`, `/proc/sys/vm/dirty_background_ratio`
- `/proc/sys/net/ipv4/tcp_available_congestion_control`
- `/proc/sys/net/ipv4/tcp_congestion_control`

## Test classification

- **Tested in the available container:** `bash -n`, automated simulation suite, CLI parsing/listing/diagnostics/dry-run/report and missing-`sysbench` branch.
- **Simulated:** fake CPUFreq, EPP, VM sysctl, TCP sysctl and block scheduler files; intent journal; rollback and conflict preservation; malicious journal path rejection; fake Kbuild source tree.
- **Not tested on a real machine:** writable CPUFreq/EPP, actual scheduler switching, actual sysctl writes, real upstream kernel build, package/boot integration, GPU tuning, power/battery behavior.
- **Not tested as separate real/VM installs:** Arch, CachyOS, EndeavourOS, Manjaro, Debian, Ubuntu, Mint, Pop!_OS, Fedora, Nobara or other derivatives.
