# LAO 1.4.0-alpha1 architecture

## Execution pipeline

1. **Discovery** (`lib/detect.sh`): reads `/etc/os-release`, checks executable package-manager availability, inventories CPU, memory, GPU, block devices, kernel/init, virtualization and selected system interfaces.
2. **Capability inspection**: reads concrete CPUFreq policy attributes, EPP preference lists, block queue scheduler lists, VM/network sysctls, PSI, DRM/PCI driver links and optional tool availability.
3. **Decision** (`lib/modules.sh`): selects CPU profile targets only from values actually advertised by the driver. Memory sysctl and storage/network writes require explicit user-supplied values; other engines remain read-only. Memory inspection now includes PSI, ZRAM/ZSWAP, THP and NUMA telemetry.
4. **Dry-run**: shows candidate changes without requiring root or writing the state journal.
5. **Transaction preparation** (`lib/common.sh`): validates the target, reads its current value, checks for a competing change, appends the intended before/after state and calls `sync -f` before mutation.
6. **Apply and verify**: writes the specific runtime kernel interface, reads it again and checks the observed result.
7. **Rollback** (`lib/state.sh`): only allowlisted modules/types/paths are accepted. A value is restored only if it still matches LAO's intended post-change value.
8. **Kernel build** (`lib/kernel_builder.sh`): prepares and optionally compiles a local kernel source tree in a separate `O=` output directory. It refuses root and never installs artifacts or changes boot configuration.

## Writable operations

| Module | Capability preconditions | Writable interface | Policy |
|---|---|---|---|
| `cpu` | CPUFreq policy exists; governor/EPP exact value is advertised; no recognized competing power manager | `scaling_governor`, `energy_performance_preference` | Profile-driven, conditional, runtime only |
| `memory` | fixed VM sysctl allowlist; explicit values and validated bounds | `/proc/sys/vm/{swappiness,vfs_cache_pressure,dirty_ratio,dirty_background_ratio}` | Manual runtime only; no inferred default |
| `storage` | selected block device exposes writable scheduler file; selected scheduler appears in its option list | `/sys/block/DEV/queue/scheduler` | Manual only; per device |
| `network` | TCP sysctl writable; requested name appears in `tcp_available_congestion_control` | `/proc/sys/net/ipv4/tcp_congestion_control` | Manual only; applies to new connections |
| `kernel`, `gpu`, `services`, `desktop`, `boot`, `security` | diagnostics/interfaces available | none | Read-only |
| `kernel-builder` | local source tree, writable unprivileged workspace, build tools and explicit confirmation for compile | local output directory | No installation or boot change |

## Journal format

`/var/lib/lao/changes.tsv` contains six tab-separated columns:

1. Run identifier.
2. Module identifier.
3. Interface type (`sysfs` or `procfs`).
4. Absolute allowlisted path.
5. Base64-encoded value before change.
6. Base64-encoded value requested after change.

The journal is root-owned and mode `0600`; its directory is root-owned and mode `0700`. The journal intent is synced before the runtime write. An intent left by a crash before the write is harmless: rollback sees that the current value is still the original and skips it.

For the block scheduler, the kernel reports the active selection in brackets beside all available names. LAO stores only the active name, and rollback reparses the bracketed active value before deciding whether it is safe to restore.

## Conflict model

Rollback compares current, before and after values. It restores only when current equals the LAO-requested after value. If current is already the before value, the record is treated as already restored. Any third value is considered an external change and is preserved.

This is not compare-and-swap: the kernel sysfs/procfs interfaces do not offer an atomic conditional write for all supported attributes. A narrow race remains between the last read and the write. The root-owned journal and allowlist reduce the blast radius but do not solve kernel-level write races.

## Module extension contract

New write-capable controls must:

- use a fixed, reviewed interface path or a strictly validated identifier under an allowlisted root;
- read and validate the current state and advertised values before proposing a change;
- require explicit input unless a profile policy has evidence-based behavior;
- journal intent before the first write;
- verify the observed state after writing;
- implement a parser-aware rollback when the interface returns structured text rather than a scalar;
- be covered by fake-interface tests, invalid-input tests, conflict tests and rollback tests.

## Deliberate non-goals in 1.4.0-alpha1

The current alpha still does not automatically tune RAM reclaim, create/configure ZRAM or ZSWAP, alter THP/NUMA, change mount options/TRIM/NVMe power states, GPU clocks/drivers, network buffers/MTU/offloads, services, desktop preferences, initramfs or bootloader entries. VM sysctl writes are runtime-only. The kernel builder does not install kernels, package them, sign modules or update boot menus.
