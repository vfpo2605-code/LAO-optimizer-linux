# Arquivos preservados, modificados e adicionados

## Preservados a partir da 1.3.0

- `lib/detect.sh`
- `lib/kernel_builder.sh`
- `config/default.conf` (comentário de versão atualizado; política mantida)
- `LICENSE`
- `docs/RESEARCH.md`

## Modificados

- `lao`: identificação da versão, ajuda e parsing dos novos controles VM; integração de variáveis e propagação de falhas.
- `lib/common.sh`: identificação da versão.
- `lib/modules.sh`: telemetria ampliada de memória/storage/GPU/rede/systemd/boot; novos sysctls VM manuais; validação e propagação de falhas.
- `lib/state.sh`: allowlist e validação de rollback para os novos sysctls VM.
- `tests/run.sh`: testes adicionais para limites, ordenação, rollback e CLI.
- `README.md`, `CHANGELOG.md`, `config/default.conf` e documentos de arquitetura/compatibilidade/limitações/testes: atualização de escopo e instruções.

## Adicionados

- `docs/AUDIT-1.3.0.md`: auditoria do estado herdado.
- `docs/IMPLEMENTATION-STATUS-1.4.0-alpha1.md`: recursos novos e pendências explícitas.
- `docs/FILE-CHANGES-1.4.0-alpha1.md`: este inventário.

## Não foi alterado

- Formato do journal TSV existente.
- Diretório de estado `/var/lib/lao`.
- Princípio de journal antes da escrita.
- Política de rollback condicional que preserva conflitos externos.
- Kernel Builder isolado em `O=` e sem instalação.
- Perfis CPUFreq/EPP e suas regras de detecção de conflitos.

Nenhum novo arquivo persistente de configuração do sistema foi criado. Os novos sysctls são alterações runtime e são revertidos pelo journal enquanto os caminhos ainda estiverem disponíveis.
