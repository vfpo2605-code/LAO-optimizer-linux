# LAO 1.4.0-alpha1 test report

**Execution date:** 2026-11-23 (UTC)  
**Execution environment:** isolated Debian GNU/Linux 13 (trixie) container  
**Kernel:** `6.18.57`  
**Architecture:** `x86_64`  
**Visible CPUs:** 3  
**Visible RAM:** 6,091,004 KiB (about 5.81 GiB)  
**Virtualization:** `container-other`  
**sysfs:** read-only mount (`ro`)  
**Bash:** GNU Bash 5.2.37

## Automated test results

All 21 test groups in `tests/run.sh` passed during the recorded run. The suite uses temporary fake sysfs/procfs regular files for write/rollback tests; these are simulations, not kernel-driver integration tests.

| Check | Result | Evidence / boundary |
|---|---|---|
| Profile normalization | PASS | balanced, low-latency and invalid profile |
| Distribution family detection | PASS (simulation) | fixture `os-release` records for Arch-like, Debian-like and Fedora-like `ID_LIKE` tokens |
| Profile governor/EPP mapping | PASS | balanced, gaming, power-saving and custom values |
| Privilege preflight | PASS (simulation + container) | Fake CPUFreq target detection plus real unprivileged read-only optimize runs |
| Tracked CPU governor/EPP writes | PASS (simulation) | Temporary regular files emulate CPUFreq attributes |
| Pre-write intent journaling | PASS (simulation) | Journal append + `sync -f` occurs before fake attribute write |
| Governor/EPP rollback | PASS (simulation) | Original values restored from fake CPUFreq tree |
| Repeated rollback | PASS (simulation) | Second rollback does not rewrite restored values |
| Preserve external change | PASS (simulation) | Later third-party value remains untouched |
| Journal path allowlist | PASS (simulation) | Crafted CPU journal path outside fake root is rejected |
| Manual memory/storage/network writes | PASS (simulation) | Explicit swappiness, VFS cache pressure, dirty ratios, scheduler and TCP controls update fake files |
| Additional memory validation | PASS (simulation) | Bounds and `dirty_background_ratio <= dirty_ratio` ordering are enforced |
| Additional memory rollback | PASS (simulation) | VFS cache pressure and dirty ratios restore exact prior values from fake procfs |
| Manual value validation | PASS (simulation) | swappiness >200 and unadvertised algorithm/scheduler rejected |
| Manual rollback | PASS (simulation) | Scheduler, TCP congestion and swappiness restored from fake interfaces |
| Manual dry-run | PASS (simulation) | Fake VM, TCP and scheduler attributes and journal remain unchanged |
| Manual external conflict | PASS (simulation) | Later swappiness value remains untouched |
| Kernel builder O= preparation | PASS (simulation) | Fake Kbuild tree executed as `nobody`; source `.config` remains unchanged |
| Kernel source fingerprint | PASS (simulation) | Non-Git source content change is detected by SHA-256 tree identity |
| Bash syntax | PASS | `bash -n` on `lao`, all libraries and tests |
| CLI listing/modules/dry-run | PASS | module list, diagnostics and dry-run paths; manual options parsed; unsupported combinations rejected |
| Benchmark input validation | PASS | invalid sample count and duration rejected |
| Text report generation | PASS | report created in temporary XDG state directory |
| Full read-only analysis | PASS | host diagnostics completed in the container |
| Missing sysbench branch | PASS | benchmark skipped cleanly; no package installed |
| Live CPUFreq/EPP write | NOT TESTED | no representative writable CPUFreq policy; `/sys` is read-only |
| Real sysctl/scheduler write | NOT TESTED | `/proc/sys` and `/sys` are not representative writable host interfaces in this container |
| Real kernel compilation | NOT TESTED | no upstream Linux source tree provided; only mock Kbuild prep was run |
| ShellCheck | NOT AVAILABLE | binary absent in authoring environment |
| shfmt | NOT AVAILABLE | binary absent in authoring environment |
| Arch/Ubuntu/Fedora target runs | NOT TESTED | no dedicated target VM or bare-metal installations available |

## Static and runtime commands executed

```bash
bash -n lao lib/*.sh tests/*.sh
bash tests/run.sh
./lao --help
./lao --list-modules
./lao --dry-run --optimize --profile gaming
./lao --dry-run --optimize --vm-swappiness 80
./lao --dry-run --optimize --device sda --io-scheduler mq-deadline
./lao --dry-run --optimize --tcp-congestion-control cubic
./lao --analyze
./lao --benchmark --benchmark-runs 1 --benchmark-seconds 3
runuser -u nobody -- ./lao --optimize --module gpu
runuser -u nobody -- ./lao --optimize --profile gaming  # no CPUFreq policy exposed in this container
```

The benchmark command followed its missing-dependency branch because `sysbench` was not installed. The unprivileged optimize runs completed in read-only mode because the selected GPU module has no writer and this container exposes no CPUFreq policies. No throughput number or performance gain was fabricated.

## Interpretation

Passing results establish tested Bash control flow, explicit-value validation, capability-list parsing, pre-write journaling, fake-interface writes, allowlisted rollback, conflict preservation, dry-run, report generation and fake Kbuild preparation. They do **not** prove real-world performance improvement or full support across all listed Linux distributions.

The container does not represent a desktop GPU, laptop battery, NVMe controller, SATA disk or physical motherboard. The read-only sysfs mount prevented testing real hardware writes. Real performance tuning, benchmark comparison, and hardware-specific compatibility remain to be validated on dedicated target systems. No benchmark gain is claimed.


## 1.4.0-alpha1 verification run

A fresh run was performed after the changes in this alpha release:

- `bash -n lao lib/*.sh tests/*.sh`: PASS.
- `bash tests/run.sh`: 21 PASS groups.
- `./lao --list-modules`: PASS.
- `./lao --module memory`, `storage`, `gpu`, `network`, `services`, `desktop`, `boot`: completed read-only in the container.
- `./lao --analyze`: completed read-only in the container.
- Dry-run CLI for VFS cache pressure and dirty ratios: PASS as part of the automated suite.
- Runtime writes against actual host sysctl/sysfs: NOT TESTED. All write/rollback validation uses temporary regular-file fixtures.
- ShellCheck, shfmt, sysbench: NOT AVAILABLE in the environment.

The additional diagnostics can show unavailable fields when running in a container or when optional utilities are absent. No performance gain is claimed.
