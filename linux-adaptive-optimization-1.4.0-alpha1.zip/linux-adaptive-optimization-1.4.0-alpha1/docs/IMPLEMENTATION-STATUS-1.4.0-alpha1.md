# LAO 1.4.0-alpha1: implementação e limites

Esta é uma versão intermediária de engenharia, não a conclusão do protocolo LAO Full Completion.

## Implementado nesta etapa

- Recuperação fiel da árvore 1.3.0 a partir do pacote versionado; o diretório incompleto anterior foi preservado em backup.
- Diagnóstico de memória expandido: PSI, THP, ZRAM (algoritmo, tamanho, limite, backing device, estatísticas), ZSWAP, NUMA, sysctls VM e swap.
- Novos controles runtime explícitos e reversíveis: `vm.vfs_cache_pressure`, `vm.dirty_ratio` e `vm.dirty_background_ratio`, além do `vm.swappiness` já existente.
- Validação dos limites dos parâmetros e da relação `dirty_background_ratio <= dirty_ratio`.
- Journal pré-escrita, verificação posterior e rollback condicional ampliados para os três novos sysctls.
- Diagnóstico de storage expandido para parâmetros de fila, descarte, read-ahead, write cache, runtime power e parâmetro global NVMe APST quando exposto.
- Diagnóstico GPU expandido para DRM sysfs, driver, IDs e alguns atributos de runtime/power/frequência quando expostos.
- Diagnóstico de rede expandido para driver, offloads, rings, coalescing e canais via ethtool quando disponível.
- Inventário de sockets/timers systemd e identificação read-only de ferramentas/layouts de boot comuns.

## Não implementado ou ainda não validado

- Dimensionamento/criação/ativação persistente de ZRAM; ZSWAP; alteração de THP; HugeTLB; políticas NUMA; reclaim adaptativo e writeback adaptativo.
- NVMe APST configurável, gestão térmica/energia por perfil, filesystem tuning, discard contínuo ou configuração automática de TRIM.
- Ajustes de GPU Intel/AMD/NVIDIA, clocks, power profiles, overclock, firmware, Mesa/RADV, VA-API ou persistência de políticas.
- Ajustes de buffers TCP/UDP, qdisc, MTU, offloads, RSS/RPS/XPS e interrupt coalescing.
- Classificação inteligente e desativação segura de serviços.
- Alteração de compositor, animações, efeitos e preferências do desktop.
- Alterações de initramfs, bootloader, módulos de boot e entradas de kernel.
- Personalização automática Kconfig por microarquitetura.
- Instalação paralela de kernel, DKMS, empacotamento, assinatura, initramfs e integração de boot.
- Benchmarks comparáveis de RAM, disco, GPU, rede, desktop e boot.
- Rollback persistente de arquivos de configuração de sistema. Os novos controles VM são runtime e normalmente voltam ao valor definido pelo sistema após reinicialização.
- Testes em hardware físico e em Arch/Manjaro/BigLinux, Debian/Ubuntu e Fedora.

## Novos comandos

```bash
# Somente leitura
./lao --module memory

# Simulação, sem root e sem journal
./lao --dry-run --optimize --vm-vfs-cache-pressure 150
./lao --dry-run --optimize --vm-dirty-ratio 30 --vm-dirty-background-ratio 10

# Aplicação runtime, requer sudo
sudo ./lao --optimize --vm-vfs-cache-pressure 150
sudo ./lao --optimize --vm-dirty-ratio 30 --vm-dirty-background-ratio 10

# Rollback de todos os controles do módulo de memória
sudo ./lao --rollback-module memory
```

Os valores acima são exemplos de sintaxe, não recomendações universais. Não os aplique sem entender a carga de trabalho e medir o resultado. Os novos parâmetros são manuais, não são escolhidos automaticamente pelos perfis.
