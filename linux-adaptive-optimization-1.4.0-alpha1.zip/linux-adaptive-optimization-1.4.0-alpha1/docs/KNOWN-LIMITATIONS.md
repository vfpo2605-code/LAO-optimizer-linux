# Known limitations in LAO 1.4.0-alpha1

1. Profiles automatically address CPUFreq governor and EPP only. They do not infer or alter VM, disk or network policy.
2. `vm.swappiness`, `vm.vfs_cache_pressure`, `vm.dirty_ratio`, `vm.dirty_background_ratio`, a block-device I/O scheduler and TCP congestion control are optional manual runtime controls. A technically accepted value is not proof of a performance gain.
3. Runtime controls are not made persistent across reboot. Persistence requires distro- and administrator-specific configuration, which LAO does not write.
4. The CPU power-manager conflict list covers common services/processes but cannot detect every vendor daemon, custom unit, desktop power service or private controller. Review the environment before applying CPU settings.
5. The journal is a narrow allowlisted runtime rollback mechanism, not a general filesystem backup or three-way merge engine.
6. A concurrent writer can still race between LAO's final read and kernel write because the exposed interfaces do not provide a compare-and-swap transaction.
7. For scheduler writes, the kernel may attempt to load the requested scheduler module when writing the sysfs attribute. LAO does not download or install packages; the module must be available to the running kernel. A loaded module may remain loaded after rollback.
8. TCP congestion-control changes apply to new connections. Existing connections are not migrated to the selected algorithm.
9. Benchmark coverage is CPU-only and depends on an already-installed `sysbench`. No storage, network, GPU, memory or boot benchmark is implemented.
10. The kernel builder fingerprints the local source tree but does not verify upstream signatures/checksums, tune Kconfig automatically, use `localmodconfig`, package, install, run `depmod`, generate initramfs, sign artifacts, modify bootloader entries or reboot.
11. A kernel source tree is executable build input. The builder refuses root execution, but users must still trust the local source and build scripts.
12. `/etc/os-release` and executable presence are useful detection signals, not proof of package/repository compatibility for every derivative. No package installation adapter is implemented.
13. GPU engine relies on exposed DRM/PCI and optional vendor tools. It does not set GPU clocks, power profiles, Mesa environment variables or driver parameters.
14. Type/speed of installed RAM may require root-readable SMBIOS data via `dmidecode`; firmware/container restrictions can make this unavailable.
15. Bare-metal regression testing on Arch, Manjaro/BigLinux, Debian, Ubuntu and Fedora variants was not available for this release. The release is an alpha milestone, not completion of the nine-engine specification.

16. Memory diagnostics now expose ZRAM/ZSWAP/THP/NUMA state but do not create or reconfigure these facilities.
17. Additional VM sysctls are runtime-only; no persistent `/etc/sysctl.d` writer or file-level rollback exists.
18. Storage/GPU/network/services/desktop/boot diagnostic expansion does not constitute active optimization or a measured performance gain.
