#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
# shellcheck source=../lib/common.sh
source "$ROOT/lib/common.sh"
# shellcheck source=../lib/state.sh
source "$ROOT/lib/state.sh"
# shellcheck source=../lib/modules.sh
source "$ROOT/lib/modules.sh"
# shellcheck source=../lib/detect.sh
source "$ROOT/lib/detect.sh"

fail() { printf 'FAIL: %s\n' "$*" >&2; exit 1; }
pass() { printf 'PASS: %s\n' "$*"; }

tmp="$(mktemp -d)"
chmod 755 "$tmp"
trap 'rm -rf -- "$tmp"' EXIT
LAO_STATE_DIR="$tmp/state"
LAO_JOURNAL="$LAO_STATE_DIR/changes.tsv"
mkdir -p "$LAO_STATE_DIR"
: > "$LAO_JOURNAL"

[[ "$(normalize_profile BALANCED)" == balanced ]] || fail "normalize_profile balanced"
[[ "$(normalize_profile low-latency)" == low-latency ]] || fail "normalize_profile low-latency"
if normalize_profile unknown >/dev/null 2>&1; then fail "unknown profile should fail"; fi
pass "profile normalization"

# Exercise derivative detection through os-release ID and ID_LIKE tokens.
arch_release="$tmp/os-release-arch"
debian_release="$tmp/os-release-debian"
fedora_release="$tmp/os-release-fedora"
printf 'ID=customarch\nID_LIKE="arch"\nPRETTY_NAME="Arch-like test"\nVERSION_ID=1\n' > "$arch_release"
printf 'ID=customdebian\nID_LIKE="ubuntu debian"\nPRETTY_NAME="Debian-like test"\nVERSION_ID=2\n' > "$debian_release"
printf 'ID=customfedora\nID_LIKE="fedora rhel"\nPRETTY_NAME="Fedora-like test"\nVERSION_ID=3\n' > "$fedora_release"
load_os_release "$arch_release"
[[ "$LAO_DISTRO_FAMILY" == arch ]] || fail "ID_LIKE arch detection"
load_os_release "$debian_release"
[[ "$LAO_DISTRO_FAMILY" == debian ]] || fail "ID_LIKE Debian/Ubuntu detection"
load_os_release "$fedora_release"
[[ "$LAO_DISTRO_FAMILY" == fedora ]] || fail "ID_LIKE Fedora/RHEL detection"
pass "distribution-family detection from os-release ID_LIKE tokens"

LAO_PROFILE=balanced
[[ "$(profile_governor_target)" == schedutil ]] || fail "balanced governor mapping"
[[ "$(profile_epp_target 'performance balance_performance balance_power power')" == balance_performance ]] || fail "balanced EPP mapping"
LAO_PROFILE=gaming
[[ "$(profile_governor_target)" == performance ]] || fail "gaming governor mapping"
[[ "$(profile_epp_target 'balance_performance performance')" == performance ]] || fail "gaming EPP mapping"
LAO_PROFILE=power-saving
[[ "$(profile_epp_target 'performance balance_power power')" == power ]] || fail "power-saving EPP mapping"
LAO_PROFILE=custom
LAO_CUSTOM_GOVERNOR=schedutil
LAO_CUSTOM_EPP=balance_power
[[ "$(profile_governor_target)" == schedutil ]] || fail "custom governor mapping"
[[ "$(profile_epp_target 'performance balance_power')" == balance_power ]] || fail "custom EPP mapping"
pass "profile-to-governor/EPP capability mapping"

# The privilege preflight should only demand root when a target would change.
CUSTOM_GOVERNOR=""
CUSTOM_EPP=""
LAO_VM_SWAPPINESS=""
LAO_STORAGE_DEVICE=""
LAO_TCP_CONGESTION=""
LAO_PROFILE=gaming
fake_policy_root="$tmp/preflight-cpufreq"
mkdir -p "$fake_policy_root/policy0"
printf 'powersave\n' > "$fake_policy_root/policy0/scaling_governor"
printf 'powersave performance\n' > "$fake_policy_root/policy0/scaling_available_governors"
printf 'performance\n' > "$fake_policy_root/policy0/energy_performance_preference"
printf 'performance\n' > "$fake_policy_root/policy0/energy_performance_available_preferences"
active_cpu_policy_managers() { :; }
optimization_may_write "$fake_policy_root" || fail "privilege preflight missed a governor change"
printf 'performance\n' > "$fake_policy_root/policy0/scaling_governor"
optimization_may_write "$fake_policy_root" && fail "privilege preflight requested root despite no CPU change"
LAO_VM_SWAPPINESS=80
optimization_may_write "$fake_policy_root" || fail "privilege preflight missed explicit manual sysctl"
LAO_VM_SWAPPINESS=""
SELECTED_MODULE=gpu
optimization_may_write "$fake_policy_root" && fail "read-only selected module should not require root"
unset SELECTED_MODULE
pass "privilege preflight distinguishes necessary writes from read-only execution"

fake_root="$tmp/cpufreq"
fake_governor="$fake_root/policy0/scaling_governor"
fake_epp="$fake_root/policy0/energy_performance_preference"
mkdir -p "${fake_governor%/*}"
printf 'powersave\n' > "$fake_governor"
printf 'balance_performance\n' > "$fake_epp"
write_sysfs_tracked cpu "$fake_governor" performance >/dev/null || fail "tracked governor write"
[[ "$(cat "$fake_governor")" == performance ]] || fail "governor write did not persist"
[[ "$(wc -l < "$LAO_JOURNAL")" -eq 1 ]] || fail "journal should contain one governor intent"
write_sysfs_tracked cpu "$fake_epp" performance >/dev/null || fail "tracked EPP write"
[[ "$(cat "$fake_epp")" == performance ]] || fail "EPP write did not persist"
[[ "$(wc -l < "$LAO_JOURNAL")" -eq 2 ]] || fail "journal should contain governor and EPP intents"
pass "tracked governor/EPP writes and pre-write journal records"

if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
  rollback_changes cpu "$fake_root" >/dev/null || fail "rollback call"
  [[ "$(cat "$fake_governor")" == powersave ]] || fail "governor rollback did not restore original"
  [[ "$(cat "$fake_epp")" == balance_performance ]] || fail "EPP rollback did not restore original"
  pass "conditional rollback restores governor and EPP"

  # Repeated rollback is idempotent.
  rollback_changes cpu "$fake_root" >/dev/null || fail "second rollback call"
  [[ "$(cat "$fake_governor")" == powersave ]] || fail "second rollback changed governor"
  pass "repeated rollback is idempotent"

  # Verify conflict-safe behavior: user change after LAO must be preserved.
  : > "$LAO_JOURNAL"
  printf 'powersave\n' > "$fake_governor"
  write_sysfs_tracked cpu "$fake_governor" performance >/dev/null || fail "second tracked write"
  printf 'user-choice\n' > "$fake_governor"
  rollback_changes cpu "$fake_root" >/dev/null || fail "conflict rollback call"
  [[ "$(cat "$fake_governor")" == user-choice ]] || fail "rollback overwrote a later user change"
  pass "rollback preserves later external changes"

  # A crafted path in the journal must never be written by rollback.
  : > "$LAO_JOURNAL"
  printf 'crafted\tcpu\tsysfs\t/etc/lao-test-not-a-real-target\t%s\t%s\n' \
    "$(printf old | base64 | tr -d '\n')" "$(printf new | base64 | tr -d '\n')" >> "$LAO_JOURNAL"
  rollback_changes all "$fake_root" >/dev/null || fail "malicious-path rollback call"
  pass "rollback rejects journal paths outside the CPUFreq allowlist"

  # Explicit/manual controls use test-only fake procfs and sysfs paths.
  : > "$LAO_JOURNAL"
  fake_vm="$tmp/proc/sys/vm/swappiness"
  fake_net="$tmp/proc/sys/net/ipv4/tcp_congestion_control"
  fake_net_available="$tmp/proc/sys/net/ipv4/tcp_available_congestion_control"
  fake_block_root="$tmp/sys-block"
  fake_scheduler="$fake_block_root/sda/queue/scheduler"
  mkdir -p "${fake_vm%/*}" "${fake_net%/*}" "${fake_scheduler%/*}"
  printf '60\n' > "$fake_vm"
  printf 'cubic\n' > "$fake_net"
  printf 'reno cubic bbr\n' > "$fake_net_available"
  printf '[mq-deadline] none bfq\n' > "$fake_scheduler"
  LAO_DRY_RUN=0
  apply_vm_swappiness 120 "$fake_vm" >/dev/null || fail "explicit swappiness write"
  [[ "$(cat "$fake_vm")" == 120 ]] || fail "swappiness write did not persist"
  apply_tcp_congestion bbr "$fake_net" "$fake_net_available" >/dev/null || fail "explicit TCP congestion write"
  [[ "$(cat "$fake_net")" == bbr ]] || fail "TCP congestion write did not persist"
  apply_storage_scheduler sda bfq "$fake_block_root" >/dev/null || fail "explicit I/O scheduler write"
  [[ "$(cat "$fake_scheduler")" == bfq ]] || fail "I/O scheduler write did not persist"
  pass "explicit swappiness, per-device I/O scheduler and TCP congestion writes"

  fake_vm_root="$tmp/proc/sys/vm"
  mkdir -p "$fake_vm_root"
  printf '100\n' > "$fake_vm_root/vfs_cache_pressure"
  printf '20\n' > "$fake_vm_root/dirty_ratio"
  printf '10\n' > "$fake_vm_root/dirty_background_ratio"
  LAO_VM_DIRTY_RATIO=""
  LAO_VM_DIRTY_BACKGROUND_RATIO=""
  apply_vm_tunable vfs_cache_pressure 150 "$fake_vm_root" >/dev/null || fail "explicit VFS cache pressure write"
  apply_vm_tunable dirty_ratio 30 "$fake_vm_root" >/dev/null || fail "explicit dirty ratio write"
  apply_vm_tunable dirty_background_ratio 15 "$fake_vm_root" >/dev/null || fail "explicit dirty background ratio write"
  [[ "$(cat "$fake_vm_root/vfs_cache_pressure")" == 150 ]] || fail "VFS cache pressure write did not persist"
  [[ "$(cat "$fake_vm_root/dirty_ratio")" == 30 ]] || fail "dirty ratio write did not persist"
  [[ "$(cat "$fake_vm_root/dirty_background_ratio")" == 15 ]] || fail "dirty background ratio write did not persist"
  if apply_vm_tunable dirty_ratio 12 "$fake_vm_root" >/dev/null 2>&1; then fail "dirty ratio below background ratio must be rejected"; fi
  if apply_vm_tunable vfs_cache_pressure 1001 "$fake_vm_root" >/dev/null 2>&1; then fail "VFS cache pressure above conservative bound must be rejected"; fi
  LAO_VM_DIRTY_RATIO=10
  LAO_VM_DIRTY_BACKGROUND_RATIO=20
  if apply_vm_tunable dirty_ratio 10 "$fake_vm_root" >/dev/null 2>&1; then fail "proposed dirty ratio must be checked against proposed background ratio"; fi
  LAO_VM_DIRTY_RATIO=""
  LAO_VM_DIRTY_BACKGROUND_RATIO=""
  pass "additional memory controls validate bounds and dirty-ratio ordering"

  rollback_changes memory "$fake_root" "$fake_block_root" "$fake_net" "$fake_vm" "$fake_vm_root" >/dev/null || fail "extended memory rollback"
  [[ "$(cat "$fake_vm_root/vfs_cache_pressure")" == 100 ]] || fail "VFS cache pressure rollback failed"
  [[ "$(cat "$fake_vm_root/dirty_ratio")" == 20 ]] || fail "dirty ratio rollback failed"
  [[ "$(cat "$fake_vm_root/dirty_background_ratio")" == 10 ]] || fail "dirty background ratio rollback failed"
  pass "additional memory controls rollback to exact previous values"

  if apply_vm_swappiness 201 "$fake_vm" >/dev/null 2>&1; then fail "swappiness above 200 must be rejected"; fi
  if apply_tcp_congestion bbr-invalid "$fake_net" "$fake_net_available" >/dev/null 2>&1; then fail "unadvertised TCP algorithm must be rejected"; fi
  if apply_storage_scheduler sda imaginary "$fake_block_root" >/dev/null 2>&1; then fail "unadvertised scheduler must be rejected"; fi
  pass "manual controls reject out-of-range or unadvertised values"

  : > "$LAO_JOURNAL"
  printf '60\n' > "$fake_vm"
  printf 'cubic\n' > "$fake_net"
  printf '[mq-deadline] none bfq\n' > "$fake_scheduler"
  LAO_DRY_RUN=1
  apply_vm_swappiness 90 "$fake_vm" >/dev/null || fail "swappiness dry-run primitive"
  apply_tcp_congestion bbr "$fake_net" "$fake_net_available" >/dev/null || fail "TCP dry-run primitive"
  apply_storage_scheduler sda bfq "$fake_block_root" >/dev/null || fail "scheduler dry-run primitive"
  [[ "$(cat "$fake_vm")" == 60 && "$(cat "$fake_net")" == cubic && "$(cat "$fake_scheduler")" == '[mq-deadline] none bfq' ]] || fail "dry-run modified fake interfaces"
  [[ ! -s "$LAO_JOURNAL" ]] || fail "dry-run wrote a journal entry"
  pass "manual dry-run leaves interfaces and journal untouched"
  LAO_DRY_RUN=0

  : > "$LAO_JOURNAL"
  apply_vm_swappiness 120 "$fake_vm" >/dev/null || fail "recreate swappiness write for rollback"
  apply_tcp_congestion bbr "$fake_net" "$fake_net_available" >/dev/null || fail "recreate TCP write for rollback"
  apply_storage_scheduler sda bfq "$fake_block_root" >/dev/null || fail "recreate scheduler write for rollback"
  rollback_changes storage "$fake_root" "$fake_block_root" >/dev/null || fail "storage rollback call"
  [[ "$(cat "$fake_scheduler")" == mq-deadline ]] || fail "storage scheduler rollback did not restore the original"
  rollback_changes network "$fake_root" "$fake_block_root" "$fake_net" >/dev/null || fail "network rollback call"
  [[ "$(cat "$fake_net")" == cubic ]] || fail "TCP congestion rollback did not restore the original"
  rollback_changes memory "$fake_root" "$fake_block_root" "$fake_net" "$fake_vm" >/dev/null || fail "memory rollback call"
  [[ "$(cat "$fake_vm")" == 60 ]] || fail "swappiness rollback did not restore the original"
  pass "conditional rollback restores storage scheduler, TCP congestion and swappiness"

  : > "$LAO_JOURNAL"
  printf '60\n' > "$fake_vm"
  apply_vm_swappiness 120 "$fake_vm" >/dev/null || fail "swappiness conflict setup"
  printf '35\n' > "$fake_vm"
  rollback_changes memory "$fake_root" "$fake_block_root" "$fake_net" "$fake_vm" >/dev/null || fail "memory conflict rollback"
  [[ "$(cat "$fake_vm")" == 35 ]] || fail "memory rollback overwrote external setting"
  pass "manual rollback preserves later external changes"
else
  printf 'SKIP: rollback tests require root because production rollback is root-only.\n'
fi

# Prepare a fake Kbuild tree as an unprivileged user. Kbuild is executable
# input, so production code deliberately refuses to run this stage as root.
if have runuser && id nobody >/dev/null 2>&1; then
  fake_source="$tmp/fake-linux"
  kernel_home="$tmp/kernel-home"
  mkdir -p "$fake_source" "$kernel_home"
  cat > "$fake_source/Makefile" <<'MAKE'
.PHONY: olddefconfig
olddefconfig:
	@test -f "$(O)/.config"
	@printf 'fake olddefconfig completed\n'
MAKE
  : > "$fake_source/Kconfig"
  printf '# CONFIG_FAKE_TEST is not set\n' > "$fake_source/.config"
  chown -R nobody "$fake_source" "$kernel_home"
  runuser -u nobody -- env HOME="$kernel_home" bash -c \
    'source "$1/lib/common.sh"; source "$1/lib/kernel_builder.sh"; kernel_builder_prepare "$2"' \
    _ "$ROOT" "$fake_source" >/dev/null || fail "kernel builder out-of-tree preparation as unprivileged user"
  prepared_config="$(find "$kernel_home" -type f -name .config -print -quit)"
  [[ -n "$prepared_config" && -r "$prepared_config" ]] || fail "prepared kernel config missing"
  [[ "$prepared_config" != "$fake_source/.config" ]] || fail "source config was used in-place"
  [[ "$(cat "$fake_source/.config")" == '# CONFIG_FAKE_TEST is not set' ]] || fail "source config was modified"
  identity_before="$(source "$ROOT/lib/common.sh"; source "$ROOT/lib/kernel_builder.sh"; kernel_source_identity "$fake_source")" || fail "kernel source identity calculation"
  printf 'source changed after preparation\n' >> "$fake_source/Kconfig"
  identity_after="$(source "$ROOT/lib/common.sh"; source "$ROOT/lib/kernel_builder.sh"; kernel_source_identity "$fake_source")" || fail "kernel source identity re-calculation"
  [[ "$identity_before" != "$identity_after" ]] || fail "kernel builder source fingerprint must detect content changes"
  pass "kernel builder creates separate O= config and preserves source config"
  pass "kernel source fingerprint detects content changes without Git metadata"
else
  printf 'SKIP: runuser/nobody unavailable; kernel builder unprivileged test not run.\n'
fi

for script in "$ROOT/lao" "$ROOT"/lib/*.sh "$ROOT"/tests/*.sh; do
  bash -n "$script" || fail "bash syntax validation: $script"
done
pass "bash syntax validation"

"$ROOT/lao" --list-modules >/dev/null || fail "module listing"
"$ROOT/lao" --module cpu >/dev/null || fail "CPU diagnostic module"
"$ROOT/lao" --module memory >/dev/null || fail "memory diagnostic module"
"$ROOT/lao" --dry-run --optimize --profile gaming >/dev/null || fail "CPU dry-run"
"$ROOT/lao" --dry-run --optimize --vm-swappiness 80 >/dev/null || fail "swappiness dry-run CLI"
"$ROOT/lao" --dry-run --optimize --vm-vfs-cache-pressure 150 >/dev/null || fail "VFS cache pressure dry-run CLI"
"$ROOT/lao" --dry-run --optimize --vm-dirty-ratio 30 --vm-dirty-background-ratio 10 >/dev/null || fail "dirty ratio dry-run CLI"
"$ROOT/lao" --dry-run --optimize --device sda --io-scheduler mq-deadline >/dev/null || fail "storage dry-run CLI"
"$ROOT/lao" --dry-run --optimize --tcp-congestion-control cubic >/dev/null || fail "network dry-run CLI"
if "$ROOT/lao" --dry-run --optimize --device sda >/dev/null 2>&1; then fail "device without scheduler must fail"; fi
if "$ROOT/lao" --vm-swappiness 80 >/dev/null 2>&1; then fail "manual tune without optimize must fail"; fi
if "$ROOT/lao" --dry-run --optimize --module cpu --vm-swappiness 80 >/dev/null 2>&1; then fail "manual parameter/module mismatch must fail"; fi
if "$ROOT/lao" --dry-run --rollback >/dev/null 2>&1; then fail "dry-run must not be silently ignored by rollback"; fi
if "$ROOT/lao" --rollback-module desktop >/dev/null 2>&1; then fail "rollback module must be writable module only"; fi
if "$ROOT/lao" --rollback --module cpu >/dev/null 2>&1; then fail "module must not be silently ignored by global rollback"; fi
if "$ROOT/lao" --rollback-module cpu --rollback >/dev/null 2>&1; then fail "global rollback must not silently override module rollback"; fi
if "$ROOT/lao" --benchmark --benchmark-runs 0 >/dev/null 2>&1; then fail "invalid benchmark sample count must fail"; fi
if "$ROOT/lao" --benchmark --benchmark-seconds 2 >/dev/null 2>&1; then fail "invalid benchmark duration must fail"; fi
pass "CLI listing, diagnostics, dry-run and benchmark input validation"

mkdir -p "$tmp/report-state"
XDG_STATE_HOME="$tmp/report-state" "$ROOT/lao" --report >/dev/null || fail "text report generation"
find "$tmp/report-state/lao/reports" -type f -name 'report-*.txt' | grep -q . || fail "report file not created"
pass "text report generation"
