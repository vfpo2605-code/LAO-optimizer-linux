# Changelog

## 1.3.0 - 2026-11-23

### Added
- Cryptographic SHA-256 fingerprint of local kernel source trees, including file contents, file/directory modes and symlink targets, with support for source archives that do not contain Git metadata.
- A test proving that changing a non-Git source tree after preparation changes its identity and invalidates the reviewed build input.

### Changed
- Kernel compilation now compares the current source-tree fingerprint with the recorded fingerprint from preparation and refuses to continue when they differ.
- Kernel Builder requires `sha256sum` for source identity verification.
- Documentation explicitly states that Kconfig is not automatically specialized by CPU microarchitecture; the builder preserves a base config and runs `olddefconfig` only.

### Validation
- Bash syntax checks and 19 automated test groups passed in an isolated Debian 13 container.
- The new source-fingerprint test uses a fake, non-Git source tree. A real upstream kernel build remains untested.

## 1.2.0 - 2026-11-23

### Added
- Explicit, validated runtime control for `vm.swappiness` (0–200).
- Explicit per-device block I/O scheduler selection from the scheduler names exposed by that device.
- Explicit TCP congestion-control selection limited to algorithms registered in the running kernel.
- Conflict-aware rollback for memory, storage and network runtime controls.
- Parser-aware scheduler tracking because the kernel brackets the currently selected scheduler in its readout.
- Distribution-family simulation tests for `ID_LIKE` tokens.
- Privilege preflight so read-only module execution and no-op optimize runs do not unnecessarily require root.
- CLI rejection for ambiguous/unsupported `--dry-run` combinations and mismatched module parameters.
- Kernel source identity with a Git working-tree fingerprint when available.

### Changed
- The transaction journal is synced before each supported runtime write.
- Kernel build workspace ownership and link checks are stricter.
- Documentation separates automatic profile controls, manual controls and diagnostic-only engines.

### Not included
- Automatic memory/storage/network profile tuning.
- GPU driver/clock tuning, service disabling, bootloader/initramfs modification or kernel installation.
- Storage/network/GPU/memory benchmarks.

### Validation
- Bash syntax checks and 18 automated test groups passed in an isolated Debian 13 container.
- Fake-interface tests cover control validation and rollback. Bare-metal writes and multi-distro VM tests remain unverified.

## 1.4.0-alpha1 - 2026-11-23

- Recuperada a árvore integral 1.3.0 a partir do pacote versionado; a cópia incompleta anterior foi preservada separadamente.
- Diagnóstico de memória expandido com PSI, THP, ZRAM/ZSWAP, NUMA e estatísticas de swap.
- Adicionados controles VM runtime explícitos para `vfs_cache_pressure`, `dirty_ratio` e `dirty_background_ratio`, com validação de limites e ordenação.
- Rollback allowlisted ampliado para os novos sysctls, preservando conflitos externos.
- Diagnóstico de storage, GPU, rede, serviços e boot ampliado sem alterar automaticamente esses subsistemas.
- Adicionados relatório de auditoria da 1.3.0 e matriz honesta do estado da 1.4.0-alpha1.
- Esta versão não conclui os nove motores do protocolo; persistência, políticas adaptativas e deploy de kernel continuam pendentes.
